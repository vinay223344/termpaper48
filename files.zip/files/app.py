"""
app.py - Enhanced QuIM-RAG UI
Run: streamlit run app.py --server.fileWatcherType none
"""
import json
import os
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import streamlit as st

st.set_page_config(
    page_title="Enhanced QuIM-RAG",
    page_icon="\U0001f9e0",
    layout="wide",
    initial_sidebar_state="expanded",
)

CHUNK_STORE = "./chunk_store_openrouter.json"
MODELS = [
    "nvidia/nemotron-3-super-120b-a12b:free",
    "google/gemma-4-31b-it:free",
    "meta-llama/llama-4-scout:free",
    "deepseek/deepseek-r1:free",
]

# ── session state ────────────────────────────────────────────────────────────
for key, val in [
    ("rag", None),
    ("chat", []),
    ("trace", []),
    ("last", None),
    ("page", "\U0001f4ac Chat"),
]:
    if key not in st.session_state:
        st.session_state[key] = val


# ── helpers ──────────────────────────────────────────────────────────────────

def load_chunks():
    p = Path(CHUNK_STORE)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


@st.cache_resource(show_spinner="Loading models (first time only)...")
def get_rag(api_key: str, model: str):
    from quim_rag_openrouter import OpenRouterConfig, QuIMRAGOpenRouter
    cfg = OpenRouterConfig(model=model)
    return QuIMRAGOpenRouter(api_key=api_key, cfg=cfg)


def crawl_site(seed_url: str, max_pages: int = 20, delay: float = 0.5):
    """
    Breadth-first crawler. Stays within the same domain.
    Returns list of {doc_id, url, text} dicts.
    """
    import time
    import hashlib
    import urllib.request
    from urllib.parse import urljoin, urlparse
    from html.parser import HTMLParser

    class PageParser(HTMLParser):
        def __init__(self):
            super().__init__()
            self._skip = False
            self.text_parts = []
            self.links = []
        def handle_starttag(self, tag, attrs):
            if tag in ("script","style","nav","footer","header","aside"):
                self._skip = True
            if tag == "a":
                for k, v in attrs:
                    if k == "href" and v:
                        self.links.append(v)
        def handle_endtag(self, tag):
            if tag in ("script","style","nav","footer","header","aside"):
                self._skip = False
        def handle_data(self, data):
            if not self._skip and data.strip():
                self.text_parts.append(data.strip())

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,*/*",
        "Accept-Language": "en-US,en;q=0.9",
    }

    domain = urlparse(seed_url).netloc
    visited = set()
    queue = [seed_url]
    pages = []

    while queue and len(pages) < max_pages:
        url = queue.pop(0)
        norm = url.rstrip("/").lower().split("?")[0]
        if norm in visited:
            continue
        visited.add(norm)

        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=15) as r:
                if "text/html" not in r.headers.get("Content-Type", ""):
                    continue
                html = r.read().decode("utf-8", errors="replace")
        except Exception:
            continue

        parser = PageParser()
        parser.feed(html)

        # Filter 404 pages
        title_check = html[:2000].lower()
        if "404" in title_check and "not found" in title_check:
            continue

        text = "\n".join(parser.text_parts).strip()
        if len(text) < 250:
            continue

        doc_id = hashlib.md5(url.encode()).hexdigest()[:12]
        pages.append({"doc_id": doc_id, "url": url, "text": text})

        # Collect links within same domain
        for href in parser.links:
            full = urljoin(url, href).split("#")[0].split("?")[0]
            p = urlparse(full)
            if (p.netloc == domain and
                    p.scheme in ("http", "https") and
                    full.rstrip("/").lower() not in visited):
                queue.append(full)

        time.sleep(delay)

    return pages


# ── sidebar ──────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("\U0001f9e0 QuIM-RAG")
    st.markdown("---")

    api_key = st.text_input("OpenRouter API Key", type="password",
                             placeholder="sk-or-...",
                             help="Free key at https://openrouter.ai")
    model = st.selectbox("Model", MODELS)

    st.markdown("---")
    st.subheader("\U0001f4e5 Ingest Document")
    seed_url = st.text_input("Seed URL", placeholder="https://example.com")
    max_pages = st.slider("Max pages to crawl", 1, 50, 20)

    if st.button("\U0001f310 Crawl & Ingest", use_container_width=True, type="primary"):
        if not api_key:
            st.warning("Enter API key first.")
        elif not seed_url.strip():
            st.warning("Enter a URL.")
        else:
            status_box = st.empty()
            progress_bar = st.progress(0, text="Starting crawler...")
            log_box = st.empty()
            crawl_log = []

            try:
                rag = get_rag(api_key, model)
            except Exception as e:
                st.error(f"RAG init failed: {e}")
                st.stop()

            try:
                import time, hashlib, urllib.request
                from urllib.parse import urljoin, urlparse
                from html.parser import HTMLParser

                class PageParser(HTMLParser):
                    def __init__(self):
                        super().__init__()
                        self._skip = False
                        self.text_parts = []
                        self.links = []
                    def handle_starttag(self, tag, attrs):
                        if tag in ("script","style","nav","footer","header","aside"):
                            self._skip = True
                        if tag == "a":
                            for k, v in attrs:
                                if k == "href" and v:
                                    self.links.append(v)
                    def handle_endtag(self, tag):
                        if tag in ("script","style","nav","footer","header","aside"):
                            self._skip = False
                    def handle_data(self, data):
                        if not self._skip and data.strip():
                            self.text_parts.append(data.strip())

                HEADERS = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36",
                    "Accept": "text/html,application/xhtml+xml,*/*",
                }

                domain = urlparse(seed_url.strip()).netloc
                visited = set()
                queue = [seed_url.strip()]
                scraped = []
                total_chunks = 0

                while queue and len(scraped) < max_pages:
                    url = queue.pop(0)
                    norm = url.rstrip("/").lower().split("?")[0]
                    if norm in visited:
                        continue
                    visited.add(norm)

                    progress_bar.progress(
                        len(scraped) / max_pages,
                        text=f"Crawling [{len(scraped)}/{max_pages}]: {url[:60]}..."
                    )

                    try:
                        req = urllib.request.Request(url, headers=HEADERS)
                        with urllib.request.urlopen(req, timeout=15) as r:
                            ct = r.headers.get("Content-Type", "")
                            if "text/html" not in ct:
                                continue
                            html = r.read().decode("utf-8", errors="replace")
                    except Exception as e:
                        crawl_log.append(f"⚠️ Skip {url[:50]}: {e}")
                        log_box.text("\n".join(crawl_log[-8:]))
                        continue

                    if "404" in html[:1000].lower() and "not found" in html[:1000].lower():
                        continue

                    parser = PageParser()
                    parser.feed(html)
                    text = "\n".join(parser.text_parts).strip()

                    if len(text) < 250:
                        crawl_log.append(f"⏭ Too short, skip: {url[:50]}")
                        log_box.text("\n".join(crawl_log[-8:]))
                        continue

                    # Ingest this page
                    doc_id = hashlib.md5(url.encode()).hexdigest()[:12]
                    try:
                        n = rag.ingest_document(doc_id, text, source_url=url)
                        total_chunks += n
                        scraped.append(url)
                        crawl_log.append(f"✅ [{len(scraped)}] {url[:55]} → {n} chunk(s)")
                    except Exception as e:
                        crawl_log.append(f"❌ Ingest error {url[:40]}: {e}")

                    log_box.text("\n".join(crawl_log[-8:]))

                    # Collect links
                    for href in parser.links:
                        full = urljoin(url, href).split("#")[0].split("?")[0]
                        p = urlparse(full)
                        if (p.netloc == domain and
                                p.scheme in ("http","https") and
                                full.rstrip("/").lower() not in visited):
                            queue.append(full)

                    time.sleep(0.3)

                progress_bar.progress(1.0, text="Done!")
                status_box.success(
                    f"Crawled **{len(scraped)}** pages → **{total_chunks}** chunks indexed!"
                )
                st.cache_resource.clear()

            except Exception as e:
                st.error(f"Crawl failed: {e}")

    st.markdown("**— or —**")

    if st.button("\U0001f4da Load Sample Docs", use_container_width=True):
        if not api_key:
            st.warning("Enter API key first.")
        else:
            SAMPLE_DOCS = [
                {
                    "doc_id": "cs_program",
                    "url": "https://catalog.ndsu.edu/undergraduate/computer-science/",
                    "text": (
                        "Computer Science B.S. at NDSU. Core Requirements 54 credits: "
                        "CSCI 160 Computer Science I 3 credits, CSCI 161 Computer Science II 3 credits, "
                        "CSCI 336 Computer Organization 3 credits, CSCI 366 Algorithms and Data Structures 3 credits, "
                        "CSCI 374 Operating Systems 3 credits, CSCI 474 Software Engineering 3 credits, "
                        "CSCI 489 Senior Capstone 3 credits, MATH 165 Calculus I 4 credits, "
                        "MATH 166 Calculus II 4 credits, STAT 330 Statistics 3 credits. "
                        "Graduation requires 122 total credits, minimum GPA 2.0 in all CSCI courses. "
                        "Transfer students may transfer up to 64 credits and must complete 30 at NDSU. "
                        "Students must complete MATH 165 and CSCI 160 with grade C or better before declaring major."
                    ),
                },
                {
                    "doc_id": "career_advising",
                    "url": "https://career-advising.ndsu.edu/contact/",
                    "text": (
                        "NDSU Career and Advising Center. Location 306 Ceres Hall Fargo ND 58108. "
                        "Phone 701-231-7111. Email ndsu.cac@ndsu.edu. "
                        "Hours Monday to Friday 9 AM to 4 PM. "
                        "Services include resume review, mock interviews, job search via Handshake, "
                        "career fairs every fall and spring semester, graduate school advising. "
                        "Drop-in hours Monday to Thursday 10 AM to 2 PM no appointment needed. "
                        "Full 30-minute appointments available via Handshake or by calling 701-231-7111."
                    ),
                },
                {
                    "doc_id": "financial_aid",
                    "url": "https://catalog.ndsu.edu/undergraduate/financial-aid/",
                    "text": (
                        "Financial Aid at NDSU. Priority Deadline February 1 for following academic year. "
                        "FAFSA school code for NDSU is 002997. Apply at studentaid.gov. "
                        "Presidential Scholarship covers full tuition renewable 4 years requires 3.9 GPA and 30 ACT. "
                        "Merit Scholarship up to 5000 dollars per year requires 3.5 GPA and 26 ACT. "
                        "Federal Pell Grant up to 7395 dollars per year for eligible students. "
                        "Federal Direct Subsidized Loan up to 5500 dollars per year for freshmen. "
                        "Work-Study provides part-time employment 10 to 15 hours per week at 12 to 15 dollars per hour. "
                        "Contact Office of Financial Aid 106 Putnam Hall Phone 701-231-6200 Email ndsu.finaid@ndsu.edu."
                    ),
                },
            ]
            with st.spinner("Indexing sample documents..."):
                try:
                    rag = get_rag(api_key, model)
                    total = 0
                    for doc in SAMPLE_DOCS:
                        n = rag.ingest_document(doc["doc_id"], doc["text"], source_url=doc["url"])
                        total += n
                        st.write(f"  ✅ {doc['doc_id']}: {n} chunk(s)")
                    st.success(f"Loaded {total} chunk(s) from {len(SAMPLE_DOCS)} sample docs!")
                    st.cache_resource.clear()
                except Exception as e:
                    st.error(f"Sample load failed: {e}")

    st.markdown("---")
    chunks = load_chunks()
    c1, c2 = st.columns(2)
    c1.metric("Chunks", len(chunks))
    c2.metric("Questions", sum(len(v.get("questions",[])) for v in chunks.values()))

    st.markdown("---")
    st.subheader("\U0001f5fa Navigate")
    page = st.radio("nav", [
        "\U0001f4ac Chat",
        "\U0001f4c4 Corpus",
        "\U0001f50d Index",
        "\U0001f4ca Evaluation",
        "\u2699\ufe0f Pipeline",
    ], label_visibility="collapsed")


# ════════════════════════════════════════════════════════════════════════════
# CHAT PAGE
# ════════════════════════════════════════════════════════════════════════════

if page == "\U0001f4ac Chat":
    st.header("\U0001f4ac Chat with QuIM-RAG")

    if not api_key:
        st.warning("Enter your OpenRouter API key in the sidebar.")
        st.stop()

    if len(chunks) == 0:
        st.info("No documents indexed yet. Paste a URL in the sidebar and click Ingest.")
        st.stop()

    # render history
    for msg in st.session_state.chat:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg["role"] == "assistant" and msg.get("meta"):
                meta = msg["meta"]
                c1, c2, c3 = st.columns(3)
                c1.caption(f"Rewritten: *{meta.get('rewritten_query','')}*")
                c2.caption(f"Hops: **{meta.get('hops',0)}**")
                c3.caption(f"Model: `{meta.get('model','')}`")
                srcs = [c.get("source_url","") for c in meta.get("contexts",[]) if c.get("source_url")]
                if srcs:
                    st.caption("Sources: " + " | ".join(f"[link]({u})" for u in dict.fromkeys(srcs)))
                with st.expander("Pipeline trace"):
                    for step in meta.get("trace", []):
                        fn = {"success": st.success, "warning": st.warning}.get(step["level"], st.info)
                        fn(f"**{step['step']}** — {step['content']}")

    # input — must be at top level, not inside any container
    user_input = st.chat_input("Ask a question...")

    if user_input:
        st.session_state.chat.append({"role": "user", "content": user_input})

        try:
            rag = get_rag(api_key, model)
        except Exception as e:
            st.error(f"Could not load RAG: {e}")
            st.stop()

        with st.spinner("Thinking..."):
            try:
                result = rag.ask(user_input)
            except Exception as e:
                st.error(f"Query failed: {e}")
                st.stop()

        answer = result.get("answer", "No answer.")
        rewritten = result.get("rewritten_query", user_input)
        hops = result.get("hops", 0)
        mdl = result.get("model", model)
        contexts = result.get("contexts", [])

        trace = [
            {"step": "1. Query Rewriting", "content": rewritten, "level": "info"},
            {"step": "2. Hybrid Retrieval", "content": f"{len(contexts)} chunk(s) retrieved", "level": "info"},
            {"step": "3. Re-Ranking", "content": "Cross-encoder applied", "level": "info"},
            {"step": "4. Multi-Hop", "content": f"{hops} hop(s)", "level": "warning" if hops > 0 else "info"},
            {"step": "5. Generation", "content": f"Answer via {mdl}", "level": "success"},
        ]
        st.session_state.trace = trace
        st.session_state.last = result

        st.session_state.chat.append({
            "role": "assistant",
            "content": answer,
            "meta": {**result, "trace": trace},
        })
        st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# CORPUS PAGE
# ════════════════════════════════════════════════════════════════════════════

elif page == "\U0001f4c4 Corpus":
    st.header("\U0001f4c4 Corpus Explorer")
    chunks = load_chunks()

    if not chunks:
        st.info("No chunks indexed yet.")
    else:
        st.caption(f"**{len(chunks)}** chunk(s) in `{CHUNK_STORE}`")
        search = st.text_input("\U0001f50e Filter by text or doc_id")

        for cid, data in chunks.items():
            doc_id = data.get("doc_id", "—")
            text = data.get("text", "")
            url = data.get("source_url", "")
            questions = data.get("questions", [])

            if search and search.lower() not in (cid + doc_id + text).lower():
                continue

            with st.expander(f"\U0001f5c2 `{cid}` — {doc_id}"):
                col1, col2 = st.columns([1, 2])
                with col1:
                    st.markdown(f"**Chunk ID:** `{cid}`")
                    st.markdown(f"**Doc ID:** `{doc_id}`")
                    st.markdown(f"**Source:** [{url}]({url})" if url else "**Source:** —")
                    st.markdown(f"**Text length:** {len(text)} chars")
                with col2:
                    st.markdown("**Text preview:**")
                    st.info(text[:500] + ("..." if len(text) > 500 else ""))

                if questions:
                    st.markdown(f"**Generated Questions ({len(questions)}):**")
                    for i, q in enumerate(questions, 1):
                        st.markdown(f"{i}. {q}")
                else:
                    st.caption("No questions for this chunk.")


# ════════════════════════════════════════════════════════════════════════════
# INDEX PAGE
# ════════════════════════════════════════════════════════════════════════════

elif page == "\U0001f50d Index":
    st.header("\U0001f50d Inverted Index — Prototype Buckets")
    chunks = load_chunks()

    if not chunks:
        st.info("No chunks indexed yet.")
    else:
        import pandas as pd

        # Build bucket map
        buckets = {}
        for data in chunks.values():
            pid = str(data.get("prototype_id", "unassigned"))
            buckets.setdefault(pid, []).append(data)

        st.metric("Total Buckets", len(buckets))
        st.metric("Total Vectors", sum(len(v) for v in buckets.values()))
        st.markdown("---")

        rows = []
        for pid, items in sorted(buckets.items(), key=lambda x: -len(x[1])):
            all_qs = [q for d in items for q in d.get("questions", [])]
            rows.append({
                "Prototype ID": pid,
                "Vectors": len(items),
                "Sample Questions": " | ".join(all_qs[:2]) if all_qs else "—",
            })

        df = pd.DataFrame(rows)
        st.subheader("Bucket Table")
        st.dataframe(df, use_container_width=True, hide_index=True)

        st.subheader("Bucket Size Distribution")
        chart_df = pd.DataFrame(
            {"Vectors": [r["Vectors"] for r in rows]},
            index=[r["Prototype ID"] for r in rows],
        )
        st.bar_chart(chart_df)

        st.subheader("Chunk Details per Bucket")
        for pid, items in sorted(buckets.items(), key=lambda x: -len(x[1])):
            with st.expander(f"Prototype {pid} — {len(items)} vector(s)"):
                for d in items:
                    st.markdown(f"- `{d.get('chunk_id','?')}` | {d.get('doc_id','?')} | {len(d.get('questions',[]))} questions")


# ════════════════════════════════════════════════════════════════════════════
# EVALUATION PAGE
# ════════════════════════════════════════════════════════════════════════════

elif page == "\U0001f4ca Evaluation":
    st.header("\U0001f4ca Evaluation")

    METRICS = ["Faithfulness","Answer Relevance","Context Precision",
               "Harmfulness","BERT-P","BERT-R","BERT-F1"]

    st.subheader("Ground Truth QA Pairs")
    st.caption("One pair per line: `question | expected answer`")
    gt_text = st.text_area("pairs", height=150, label_visibility="collapsed",
        placeholder="What is the graduation GPA? | 2.0 minimum GPA\nWhere is the advising center? | 306 Ceres Hall")

    if st.button("\u25b6 Run Evaluation", type="primary"):
        if not api_key:
            st.warning("Enter API key first.")
        elif not gt_text.strip():
            st.warning("Enter at least one QA pair.")
        elif len(chunks) == 0:
            st.info("Ingest a document first.")
        else:
            pairs = []
            for line in gt_text.strip().splitlines():
                if "|" in line:
                    q, a = line.split("|", 1)
                    pairs.append((q.strip(), a.strip()))

            if not pairs:
                st.warning("No valid pairs found. Use format: question | answer")
            else:
                try:
                    rag = get_rag(api_key, model)
                except Exception as e:
                    st.error(f"RAG init failed: {e}")
                    st.stop()

                from difflib import SequenceMatcher
                import pandas as pd

                def sim(a, b):
                    return round(SequenceMatcher(None, a.lower(), b.lower()).ratio(), 3)

                results = []
                bar = st.progress(0)
                for i, (q, expected) in enumerate(pairs):
                    try:
                        res = rag.ask(q)
                        pred = res.get("answer", "")
                        ctx = " ".join(c.get("snippet","") for c in res.get("contexts",[]))
                        pt = set(pred.lower().split())
                        et = set(expected.lower().split())
                        bp = round(len(pt&et)/len(pt),3) if pt else 0
                        br = round(len(pt&et)/len(et),3) if et else 0
                        bf = round(2*bp*br/(bp+br),3) if (bp+br) else 0
                        results.append({
                            "Question": q,
                            "Expected": expected,
                            "Predicted": pred[:100]+"..." if len(pred)>100 else pred,
                            "Faithfulness": sim(pred, ctx),
                            "Answer Relevance": sim(pred, q),
                            "Context Precision": sim(ctx, expected),
                            "Harmfulness": 0.0,
                            "BERT-P": bp, "BERT-R": br, "BERT-F1": bf,
                        })
                    except Exception as e:
                        results.append({"Question": q, "Expected": expected,
                                        "Predicted": f"ERROR: {e}",
                                        **{m: 0.0 for m in METRICS}})
                    bar.progress((i+1)/len(pairs))

                bar.empty()
                import pandas as pd
                df = pd.DataFrame(results)
                st.subheader("Results")
                st.dataframe(df, use_container_width=True, hide_index=True)

                avgs = {m: round(df[m].mean(), 3) for m in METRICS}
                st.subheader("Average Scores")
                cols = st.columns(len(METRICS))
                for col, (m, v) in zip(cols, avgs.items()):
                    col.metric(m, v)

                chart_df = pd.DataFrame({"Score": list(avgs.values())}, index=list(avgs.keys()))
                st.bar_chart(chart_df)


# ════════════════════════════════════════════════════════════════════════════
# PIPELINE PAGE
# ════════════════════════════════════════════════════════════════════════════

elif page == "\u2699\ufe0f Pipeline":
    st.header("\u2699\ufe0f Pipeline Trace")

    trace = st.session_state.trace
    last = st.session_state.last

    if not trace:
        st.info("Ask a question in the Chat page to see the pipeline trace here.")
    else:
        if last:
            st.caption(f"Query: **{last.get('query','')}** | Hops: **{last.get('hops',0)}** | Model: `{last.get('model','')}`")
        st.markdown("---")

        for i, step in enumerate(trace, 1):
            fn = {"success": st.success, "warning": st.warning, "error": st.error}.get(step["level"], st.info)
            fn(f"**Step {i} — {step['step']}**\n\n{step['content']}")

        if st.button("\U0001f5d1 Clear Trace"):
            st.session_state.trace = []
            st.session_state.last = None
            st.rerun()

        if last:
            with st.expander("Full result JSON"):
                st.json(last)

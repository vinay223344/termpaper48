"""
main_ollama.py — QuIM-RAG with Ollama (free, local)

Usage:
    # Demo mode (no Ollama needed)
    python main_ollama.py --demo

    # Live mode with sample docs
    python main_ollama.py --model llama3.2

    # Live mode with web scraping
    python main_ollama.py --model llama3.2 --seed_url https://catalog.ndsu.edu

Setup (one-time):
    1. Download Ollama: https://ollama.com/download
    2. ollama pull llama3.2        (2GB, fast)
       or
       ollama pull llama3.1:8b    (5GB, better quality)
    3. python main_ollama.py --model llama3.2
"""

from __future__ import annotations

import argparse
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

SAMPLE_DOCS = [
    {
        "doc_id": "cs_program",
        "url": "https://catalog.ndsu.edu/undergraduate/computer-science/",
        "text": """
Computer Science (B.S.) — NDSU
The Bachelor of Science in Computer Science at North Dakota State University
prepares students for careers in software development, data science, AI,
and systems programming.

Core Requirements (54 credits):
- CSCI 160: Computer Science I (3 credits)
- CSCI 161: Computer Science II (3 credits)
- CSCI 336: Computer Organization (3 credits)
- CSCI 366: Algorithms and Data Structures (3 credits)
- CSCI 374: Operating Systems (3 credits)
- CSCI 474: Software Engineering (3 credits)
- CSCI 489: Senior Capstone (3 credits)
- MATH 165, 166: Calculus I & II (8 credits)
- STAT 330: Statistics (3 credits)

Graduation Requirements:
Students must complete 122 total credits with a minimum GPA of 2.0 in all
CSCI courses. A senior capstone project is required.

Transfer Students:
Transfer students may transfer up to 64 credits. Must complete at least
30 credits at NDSU before graduating.
        """,
    },
    {
        "doc_id": "career_advising",
        "url": "https://career-advising.ndsu.edu/contact/",
        "text": """
NDSU Career and Advising Center — Contact Information

Location: 306 Ceres Hall, Fargo, ND 58108
Phone: 701-231-7111
Email: ndsu.cac@ndsu.edu
Hours: Monday–Friday, 9 AM–4 PM

Services:
- Resume and cover letter review
- Mock interview preparation
- Job and internship search via Handshake
- Career fairs (fall and spring)
- Graduate school advising

Drop-In Hours: Monday–Thursday 10 AM–2 PM (no appointment needed)
Full appointments: 30 minutes, book via Handshake or call 701-231-7111
        """,
    },
]


def check_ollama_running() -> bool:
    try:
        import ollama
        ollama.list()
        return True
    except Exception:
        return False


def run_demo() -> None:
    print("\n" + "=" * 55)
    print("QuIM-RAG Ollama — Demo Mode")
    print("=" * 55)
    print("\nThis demo shows the pipeline without running Ollama.")
    print("\nTo run live:")
    print("  1. Install Ollama: https://ollama.com/download")
    print("  2. ollama pull llama3.2")
    print("  3. python main_ollama.py --model llama3.2")
    print("\nPipeline steps:")
    print("  [1] Web scraper crawls target URLs")
    print("  [2] Text chunked into 1000-token overlapping chunks")
    print("  [3] Ollama generates questions per chunk (FREE, local)")
    print("  [4] BAAI/bge-large-en-v1.5 embeds questions → ChromaDB")
    print("  [5] BM25 sparse index built over raw chunk text")
    print("  [6] Query rewriting via Ollama")
    print("  [7] Hybrid retrieval (dense + BM25) with RRF fusion")
    print("  [8] Cross-encoder re-ranking (ms-marco-MiniLM-L-6-v2)")
    print("  [9] Multi-hop reasoning if context is insufficient")
    print("  [10] Answer generation via Ollama")
    print("\n" + "=" * 55)


def run_live(model: str, seed_url: str | None = None) -> None:
    if not check_ollama_running():
        print("\n[ERROR] Ollama is not running.")
        print("  Start it with: ollama serve")
        print("  Then pull a model: ollama pull", model)
        return

    from quim_rag_ollama import OllamaConfig, QuIMRAGOllama
    from feedback import FeedbackEntry, FeedbackStore

    cfg = OllamaConfig(generator_model=model, question_gen_model=model)
    rag = QuIMRAGOllama(cfg)

    # Ingest
    if seed_url:
        from web_scraper import WebScraper
        log.info(f"Crawling {seed_url} ...")
        pages = WebScraper(seed_url, max_pages=20).crawl()
        for page in pages:
            rag.ingest_document(page.doc_id, page.text, page.url)
    else:
        log.info("Using sample documents ...")
        for doc in SAMPLE_DOCS:
            rag.ingest_document(doc["doc_id"], doc["text"], doc["url"])

    # QA loop
    store = FeedbackStore("./feedback_log_ollama.jsonl")
    print(f"\nQuIM-RAG (Ollama/{model}) is ready. Type 'quit' to exit.\n")

    while True:
        query = input("Your question: ").strip()
        if query.lower() in ("quit", "exit", "q"):
            break
        if not query:
            continue

        result = rag.ask(query)

        print(f"\nAnswer:\n{result['answer']}\n")
        print(f"Rewritten query : {result['rewritten_query']}")
        print(f"Multi-hop rounds: {result['hops']}")
        print("Sources:")
        for ctx in result["contexts"]:
            if ctx["source_url"]:
                print(f"  {ctx['source_url']}  (score: {ctx['score']:.3f})")

        rating = input("\nRate (y=good / n=bad / s=skip): ").strip().lower()
        if rating in ("y", "n"):
            store.log(FeedbackEntry(
                query=result["query"],
                rewritten_query=result["rewritten_query"],
                answer=result["answer"],
                chunk_ids=[c["chunk_id"] for c in result["contexts"]],
                chunk_texts=[c["snippet"] for c in result["contexts"]],
                rating=1 if rating == "y" else 0,
            ))
        print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="QuIM-RAG with Ollama")
    parser.add_argument("--model", default="llama3.2", help="Ollama model name")
    parser.add_argument("--seed_url", default="", help="URL to crawl")
    parser.add_argument("--demo", action="store_true", help="Show demo without Ollama")
    args = parser.parse_args()

    if args.demo:
        run_demo()
    else:
        run_live(args.model, args.seed_url or None)

"""
QuIM-RAG: Question-to-question Inverted Index Matching RAG System
Based on: "QuIM-RAG: Advancing Retrieval-Augmented Generation With Inverted
Question Matching for Enhanced QA Performance" (Saha et al., 2024)

This module implements the core QuIM-RAG pipeline:
  1. Corpus ingestion & chunking
  2. Question generation from chunks (via LLM)
  3. Embedding + quantization into inverted index (ChromaDB)
  4. Query processing & top-k retrieval
  5. Answer generation (via LLM)

Extensions implemented:
  - Query rewriting (pre-retrieval LLM pass)
  - Hybrid retrieval  (BM25 + dense, fused via RRF)
  - Cross-encoder re-ranking
  - Multi-hop reasoning loop
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import chromadb
from chromadb.config import Settings
from openai import OpenAI
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder, SentenceTransformer

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class QuIMConfig:
    """All tuneable knobs in one place."""

    # Models
    embedding_model: str = "BAAI/bge-large-en-v1.5"
    generator_model: str = "gpt-3.5-turbo"          # swap for local LLM
    question_gen_model: str = "gpt-3.5-turbo"
    reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"

    # Chunking
    chunk_size: int = 1000          # tokens
    chunk_overlap: int = 200        # characters

    # Retrieval
    top_k: int = 3                  # questions to match
    hybrid_alpha: float = 0.5       # weight: dense vs BM25 (0 = BM25 only, 1 = dense only)
    rrf_k: int = 60                 # reciprocal rank fusion constant

    # Multi-hop
    max_hops: int = 2               # additional retrieval rounds
    hop_threshold: float = 0.6      # confidence below which we do another hop

    # Storage
    chroma_persist_dir: str = "./chroma_db"
    collection_name: str = "quim_rag"
    chunk_store_path: str = "./chunk_store.json"


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    text: str
    source_url: str = ""
    questions: list[str] = field(default_factory=list)


@dataclass
class RetrievedContext:
    chunk: Chunk
    score: float
    matched_question: str


# ---------------------------------------------------------------------------
# 1. Corpus ingestion & chunking
# ---------------------------------------------------------------------------

class CorpusIngester:
    """
    Splits raw documents into overlapping token-based chunks.
    Uses tiktoken for accurate token counting (matches GPT tokeniser).
    """

    def __init__(self, cfg: QuIMConfig):
        self.cfg = cfg
        try:
            import tiktoken
            self._enc = tiktoken.get_encoding("cl100k_base")
        except ImportError:
            log.warning("tiktoken not installed – falling back to word splitting")
            self._enc = None

    def _tokenize(self, text: str) -> list[str]:
        if self._enc:
            return self._enc.encode(text)
        return text.split()

    def _detokenize(self, tokens) -> str:
        if self._enc:
            return self._enc.decode(tokens)
        return " ".join(tokens)

    def chunk_document(self, doc_id: str, text: str, source_url: str = "") -> list[Chunk]:
        """Return overlapping chunks for a single document."""
        tokens = self._tokenize(text)
        chunks: list[Chunk] = []
        step = self.cfg.chunk_size - self.cfg.chunk_overlap // 4  # approx overlap

        for i, start in enumerate(range(0, len(tokens), step)):
            end = min(start + self.cfg.chunk_size, len(tokens))
            chunk_text = self._detokenize(tokens[start:end])

            # Skip tiny / empty chunks
            if len(chunk_text.strip()) < 250:
                continue

            chunk_id = hashlib.md5(f"{doc_id}_{i}".encode()).hexdigest()[:12]
            chunks.append(Chunk(
                chunk_id=chunk_id,
                doc_id=doc_id,
                text=chunk_text,
                source_url=source_url,
            ))

            if end >= len(tokens):
                break

        log.info(f"[Ingester] {doc_id}: {len(chunks)} chunks produced")
        return chunks


# ---------------------------------------------------------------------------
# 2. Question generation
# ---------------------------------------------------------------------------

QUESTION_GEN_PROMPT = """\
You are an expert at generating diverse, comprehensive questions from text.

Given the following text chunk, generate a set of questions that:
- Cover ALL key information and concepts in the chunk
- Are unique and non-redundant
- Are clear, direct, and self-contained
- Would naturally be asked by a user seeking this information

Return ONLY a JSON array of question strings. No preamble.

Text chunk:
\"\"\"
{chunk_text}
\"\"\"
"""


class QuestionGenerator:
    """Generates a set of potential questions for each chunk using an LLM."""

    def __init__(self, cfg: QuIMConfig, client: OpenAI):
        self.cfg = cfg
        self.client = client

    def generate(self, chunk: Chunk, max_questions: int = 8) -> list[str]:
        prompt = QUESTION_GEN_PROMPT.format(chunk_text=chunk.text[:3000])
        try:
            resp = self.client.chat.completions.create(
                model=self.cfg.question_gen_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=600,
            )
            raw = resp.choices[0].message.content.strip()
            # Strip markdown fences if present
            raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.MULTILINE)
            questions = json.loads(raw)
            return [q.strip() for q in questions if q.strip()][:max_questions]
        except Exception as e:
            log.warning(f"[QGen] Failed for chunk {chunk.chunk_id}: {e}")
            return []


# ---------------------------------------------------------------------------
# 3. Embedding + inverted index (ChromaDB)
# ---------------------------------------------------------------------------

class InvertedIndex:
    """
    Embeds generated questions, quantises them to nearest prototype (via
    ChromaDB's HNSW index), and builds the inverted index mapping
    prototype → {(embedding_id, chunk_id)}.
    """

    def __init__(self, cfg: QuIMConfig):
        self.cfg = cfg
        self.embed_model = SentenceTransformer(cfg.embedding_model)

        chroma_client = chromadb.PersistentClient(
            path=cfg.chroma_persist_dir,
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = chroma_client.get_or_create_collection(
            name=cfg.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        log.info(f"[Index] Collection '{cfg.collection_name}' ready "
                 f"({self.collection.count()} vectors)")

    def add_chunk(self, chunk: Chunk) -> None:
        """Embed all questions for a chunk and upsert into the index."""
        if not chunk.questions:
            return

        embeddings = self.embed_model.encode(
            chunk.questions, normalize_embeddings=True
        ).tolist()

        ids, docs, metas, embs = [], [], [], []
        for q_idx, (q, emb) in enumerate(zip(chunk.questions, embeddings)):
            vec_id = f"{chunk.chunk_id}_q{q_idx}"
            ids.append(vec_id)
            docs.append(q)
            metas.append({
                "chunk_id": chunk.chunk_id,
                "doc_id": chunk.doc_id,
                "source_url": chunk.source_url,
            })
            embs.append(emb)

        self.collection.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=embs)

    def query(self, query_text: str, top_k: int = 10) -> list[dict]:
        """Return top_k question vectors closest to the query embedding."""
        q_emb = self.embed_model.encode(
            [query_text], normalize_embeddings=True
        ).tolist()
        results = self.collection.query(
            query_embeddings=q_emb,
            n_results=min(top_k, max(1, self.collection.count())),
            include=["documents", "metadatas", "distances"],
        )
        hits = []
        if results["ids"] and results["ids"][0]:
            for vec_id, doc, meta, dist in zip(
                results["ids"][0],
                results["documents"][0],
                results["metadatas"][0],
                results["distances"][0],
            ):
                hits.append({
                    "vec_id": vec_id,
                    "question": doc,
                    "chunk_id": meta["chunk_id"],
                    "doc_id": meta["doc_id"],
                    "source_url": meta.get("source_url", ""),
                    "distance": dist,
                    "score": 1.0 - dist,   # cosine distance → similarity
                })
        return hits

    def delete_chunk(self, chunk_id: str) -> None:
        """Remove all question vectors for a chunk (used for dynamic updates)."""
        results = self.collection.get(where={"chunk_id": chunk_id})
        if results["ids"]:
            self.collection.delete(ids=results["ids"])
            log.info(f"[Index] Deleted {len(results['ids'])} vectors for chunk {chunk_id}")


# ---------------------------------------------------------------------------
# 4a. Extension — Query Rewriting
# ---------------------------------------------------------------------------

REWRITE_PROMPT = """\
Rewrite the following user question to be more specific, self-contained, and
suitable for searching a university knowledge base (admissions, courses,
career advising, campus services). Return ONLY the rewritten question.

Original question: {query}
"""


class QueryRewriter:
    """
    Pre-retrieval module: rewrites vague/short queries before embedding.
    Falls back to the original query on any failure.
    """

    def __init__(self, cfg: QuIMConfig, client: OpenAI):
        self.cfg = cfg
        self.client = client

    def rewrite(self, query: str) -> str:
        if len(query.split()) > 10:
            return query   # long queries are usually specific enough
        try:
            resp = self.client.chat.completions.create(
                model=self.cfg.generator_model,
                messages=[{"role": "user", "content": REWRITE_PROMPT.format(query=query)}],
                temperature=0.0,
                max_tokens=100,
            )
            rewritten = resp.choices[0].message.content.strip()
            log.info(f"[Rewriter] '{query}' → '{rewritten}'")
            return rewritten
        except Exception as e:
            log.warning(f"[Rewriter] Fallback to original query: {e}")
            return query


# ---------------------------------------------------------------------------
# 4b. Extension — Hybrid Retrieval (BM25 + Dense via RRF)
# ---------------------------------------------------------------------------

class HybridRetriever:
    """
    Combines dense (inverted index) and sparse (BM25) retrieval using
    Reciprocal Rank Fusion (RRF).

    RRF score = 1/(k + rank_dense) + 1/(k + rank_sparse)
    """

    def __init__(self, cfg: QuIMConfig, index: InvertedIndex, chunks: list[Chunk]):
        self.cfg = cfg
        self.index = index
        self._build_bm25(chunks)

    def _build_bm25(self, chunks: list[Chunk]) -> None:
        self.chunks_by_id: dict[str, Chunk] = {c.chunk_id: c for c in chunks}
        self.chunk_order = [c.chunk_id for c in chunks]
        if not chunks:
            log.warning("[BM25] No chunks available — BM25 index skipped")
            self.bm25 = None
            return
        tokenized = [c.text.lower().split() for c in chunks]
        self.bm25 = BM25Okapi(tokenized)
        log.info(f"[BM25] Index built over {len(chunks)} chunks")

    def retrieve(self, query: str, top_k: int) -> list[dict]:
        # --- Dense retrieval ---
        dense_hits = self.index.query(query, top_k=top_k * 3)
        dense_chunk_scores: dict[str, float] = {}
        for rank, hit in enumerate(dense_hits):
            cid = hit["chunk_id"]
            if cid not in dense_chunk_scores:
                dense_chunk_scores[cid] = 1.0 / (self.cfg.rrf_k + rank + 1)

        # --- Sparse (BM25) retrieval ---
        if self.bm25 is None:
            sparse_chunk_scores: dict[str, float] = {}
            all_chunk_ids = set(dense_chunk_scores)
            fused: list[tuple[str, float]] = [(cid, s) for cid, s in dense_chunk_scores.items()]
            fused.sort(key=lambda x: x[1], reverse=True)
            results = []
            for cid, score in fused[:top_k]:
                chunk = self.chunks_by_id.get(cid)
                if chunk is None:
                    continue
                matched_q = next(
                    (h["question"] for h in dense_hits if h["chunk_id"] == cid),
                    chunk.questions[0] if chunk.questions else "",
                )
                results.append({"chunk_id": cid, "question": matched_q, "score": score, "source_url": chunk.source_url})
            return results
        bm25_scores = self.bm25.get_scores(query.lower().split())
        ranked_sparse = sorted(
            enumerate(bm25_scores), key=lambda x: x[1], reverse=True
        )[: top_k * 3]
        sparse_chunk_scores: dict[str, float] = {}
        for rank, (idx, _) in enumerate(ranked_sparse):
            cid = self.chunk_order[idx]
            sparse_chunk_scores[cid] = 1.0 / (self.cfg.rrf_k + rank + 1)

        # --- Fuse ---
        all_chunk_ids = set(dense_chunk_scores) | set(sparse_chunk_scores)
        fused: list[tuple[str, float]] = []
        for cid in all_chunk_ids:
            score = (
                self.cfg.hybrid_alpha * dense_chunk_scores.get(cid, 0.0)
                + (1 - self.cfg.hybrid_alpha) * sparse_chunk_scores.get(cid, 0.0)
            )
            fused.append((cid, score))

        fused.sort(key=lambda x: x[1], reverse=True)

        # Build result dicts mirroring the dense format
        results = []
        for cid, score in fused[:top_k]:
            chunk = self.chunks_by_id.get(cid)
            if chunk is None:
                continue
            # Find the best matching question from dense hits for this chunk
            matched_q = next(
                (h["question"] for h in dense_hits if h["chunk_id"] == cid),
                chunk.questions[0] if chunk.questions else "",
            )
            results.append({
                "chunk_id": cid,
                "question": matched_q,
                "score": score,
                "source_url": chunk.source_url,
            })
        return results


# ---------------------------------------------------------------------------
# 4c. Extension — Cross-Encoder Re-Ranking
# ---------------------------------------------------------------------------

class Reranker:
    """
    Re-scores (query, chunk_text) pairs using a cross-encoder for higher
    precision before passing context to the LLM.
    """

    def __init__(self, cfg: QuIMConfig):
        self.model = CrossEncoder(cfg.reranker_model)
        log.info(f"[Reranker] Loaded {cfg.reranker_model}")

    def rerank(
        self,
        query: str,
        hits: list[dict],
        chunks_by_id: dict[str, Chunk],
        top_k: int,
    ) -> list[dict]:
        pairs = []
        for hit in hits:
            chunk = chunks_by_id.get(hit["chunk_id"])
            text = chunk.text[:512] if chunk else hit.get("question", "")
            pairs.append((query, text))

        ce_scores = self.model.predict(pairs).tolist()
        for hit, score in zip(hits, ce_scores):
            hit["rerank_score"] = score

        reranked = sorted(hits, key=lambda h: h["rerank_score"], reverse=True)
        log.info(f"[Reranker] Top rerank score: {reranked[0]['rerank_score']:.3f}")
        return reranked[:top_k]


# ---------------------------------------------------------------------------
# 4d. Extension — Multi-hop Reasoning
# ---------------------------------------------------------------------------

SUBQUERY_PROMPT = """\
You are answering a complex question using retrieved context.
The context so far is insufficient to answer fully.

Original question: {query}
Partial context: {partial_context}

Identify ONE specific sub-question whose answer would help complete the
response. Return ONLY the sub-question, nothing else.
"""


class MultiHopReasoner:
    """
    Iteratively retrieves additional context when the first pass is
    insufficient, up to max_hops additional rounds.
    """

    def __init__(self, cfg: QuIMConfig, client: OpenAI):
        self.cfg = cfg
        self.client = client

    def needs_another_hop(self, query: str, context: str) -> bool:
        """Heuristic: does the context look too short / unrelated?"""
        word_overlap = len(
            set(query.lower().split()) & set(context.lower().split())
        )
        return word_overlap < 3 and len(context) < 400

    def generate_subquery(self, query: str, partial_context: str) -> str:
        try:
            resp = self.client.chat.completions.create(
                model=self.cfg.generator_model,
                messages=[{
                    "role": "user",
                    "content": SUBQUERY_PROMPT.format(
                        query=query,
                        partial_context=partial_context[:800],
                    ),
                }],
                temperature=0.2,
                max_tokens=80,
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            log.warning(f"[MultiHop] Subquery generation failed: {e}")
            return query


# ---------------------------------------------------------------------------
# 5. Answer Generation
# ---------------------------------------------------------------------------

ANSWER_PROMPT = """\
You are a helpful assistant for North Dakota State University (NDSU).
Answer questions ONLY based on the provided context.
Always include the source URL when available.

If the context does not contain enough information to answer the question,
say: "I cannot find an answer to this question in the available information."

Context:
{context}

Question: {question}

Answer:"""


class AnswerGenerator:
    def __init__(self, cfg: QuIMConfig, client: OpenAI):
        self.cfg = cfg
        self.client = client

    def generate(self, query: str, contexts: list[RetrievedContext]) -> str:
        context_blocks = []
        for i, ctx in enumerate(contexts, 1):
            block = f"[{i}] {ctx.chunk.text[:800]}"
            if ctx.chunk.source_url:
                block += f"\nSource: {ctx.chunk.source_url}"
            context_blocks.append(block)

        context_str = "\n\n".join(context_blocks)
        prompt = ANSWER_PROMPT.format(context=context_str, question=query)

        try:
            resp = self.client.chat.completions.create(
                model=self.cfg.generator_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=512,
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            log.error(f"[Generator] Failed: {e}")
            return "Error generating answer."


# ---------------------------------------------------------------------------
# Chunk store (simple JSON persistence)
# ---------------------------------------------------------------------------

class ChunkStore:
    """Persists chunks to disk so BM25 and re-ranker can access raw text."""

    def __init__(self, path: str):
        self.path = Path(path)
        self._data: dict[str, dict] = {}
        if self.path.exists():
            self._data = json.loads(self.path.read_text())
            log.info(f"[ChunkStore] Loaded {len(self._data)} chunks from {path}")

    def save_chunk(self, chunk: Chunk) -> None:
        self._data[chunk.chunk_id] = {
            "chunk_id": chunk.chunk_id,
            "doc_id": chunk.doc_id,
            "text": chunk.text,
            "source_url": chunk.source_url,
            "questions": chunk.questions,
        }

    def get_chunk(self, chunk_id: str) -> Chunk | None:
        d = self._data.get(chunk_id)
        if d is None:
            return None
        return Chunk(**d)

    def all_chunks(self) -> list[Chunk]:
        return [Chunk(**d) for d in self._data.values()]

    def flush(self) -> None:
        self.path.write_text(json.dumps(self._data, indent=2))
        log.info(f"[ChunkStore] Flushed {len(self._data)} chunks to {self.path}")

    def delete_chunk(self, chunk_id: str) -> None:
        self._data.pop(chunk_id, None)


# ---------------------------------------------------------------------------
# QuIM-RAG Pipeline — ties everything together
# ---------------------------------------------------------------------------

class QuIMRAG:
    """
    End-to-end QuIM-RAG pipeline with all extensions.

    Usage:
        rag = QuIMRAG(cfg, openai_api_key="sk-...")
        rag.ingest_document("doc1", text, source_url="https://...")
        answer = rag.ask("What are the CS graduation requirements?")
    """

    def __init__(self, cfg: QuIMConfig, openai_api_key: str):
        self.cfg = cfg
        self.client = OpenAI(api_key=openai_api_key)

        self.ingester = CorpusIngester(cfg)
        self.qgen = QuestionGenerator(cfg, self.client)
        self.index = InvertedIndex(cfg)
        self.chunk_store = ChunkStore(cfg.chunk_store_path)
        self.rewriter = QueryRewriter(cfg, self.client)
        self.reranker = Reranker(cfg)
        self.multihop = MultiHopReasoner(cfg, self.client)
        self.generator = AnswerGenerator(cfg, self.client)

        # Build BM25 over persisted chunks
        all_chunks = self.chunk_store.all_chunks()
        if all_chunks:
            self.hybrid = HybridRetriever(cfg, self.index, all_chunks)
        else:
            self.hybrid = None

    # --- Ingestion ---

    def ingest_document(
        self,
        doc_id: str,
        text: str,
        source_url: str = "",
        regenerate: bool = False,
    ) -> int:
        """Chunk, generate questions, embed and store. Returns number of chunks."""
        chunks = self.ingester.chunk_document(doc_id, text, source_url)
        new_count = 0

        for chunk in chunks:
            existing = self.chunk_store.get_chunk(chunk.chunk_id)
            if existing and not regenerate:
                log.info(f"[Ingest] Chunk {chunk.chunk_id} already indexed, skipping")
                continue

            # Generate questions
            chunk.questions = self.qgen.generate(chunk)
            if not chunk.questions:
                log.warning(f"[Ingest] No questions for chunk {chunk.chunk_id}, skipping")
                continue

            # Index and persist
            self.index.add_chunk(chunk)
            self.chunk_store.save_chunk(chunk)
            new_count += 1

        self.chunk_store.flush()

        # Rebuild BM25 to include new chunks
        all_chunks = self.chunk_store.all_chunks()
        if all_chunks:
            self.hybrid = HybridRetriever(self.cfg, self.index, all_chunks)
        else:
            log.warning("[Ingest] No chunks in store yet — hybrid retriever not built")
            self.hybrid = None

        log.info(f"[Ingest] {new_count} new chunks indexed for doc '{doc_id}'")
        return new_count

    def update_document(self, doc_id: str, text: str, source_url: str = "") -> int:
        """Dynamic update: remove old chunks for doc_id, re-ingest with new text."""
        old_chunks = [c for c in self.chunk_store.all_chunks() if c.doc_id == doc_id]
        for chunk in old_chunks:
            self.index.delete_chunk(chunk.chunk_id)
            self.chunk_store.delete_chunk(chunk.chunk_id)
        log.info(f"[Update] Removed {len(old_chunks)} old chunks for '{doc_id}'")
        return self.ingest_document(doc_id, text, source_url, regenerate=True)

    # --- Retrieval ---

    def _retrieve(self, query: str) -> list[dict]:
        if self.hybrid:
            return self.hybrid.retrieve(query, top_k=self.cfg.top_k * 3)
        return self.index.query(query, top_k=self.cfg.top_k * 3)

    def _hits_to_contexts(self, hits: list[dict]) -> list[RetrievedContext]:
        chunks_by_id = {c.chunk_id: c for c in self.chunk_store.all_chunks()}
        contexts = []
        seen = set()
        for hit in hits:
            cid = hit["chunk_id"]
            if cid in seen:
                continue
            seen.add(cid)
            chunk = chunks_by_id.get(cid)
            if chunk:
                contexts.append(RetrievedContext(
                    chunk=chunk,
                    score=hit.get("rerank_score", hit.get("score", 0.0)),
                    matched_question=hit.get("question", ""),
                ))
        return contexts

    # --- Main QA entry point ---

    def ask(
        self,
        query: str,
        use_rewriter: bool = True,
        use_reranker: bool = True,
        use_multihop: bool = True,
    ) -> dict[str, Any]:
        """
        Full QuIM-RAG pipeline: rewrite → retrieve → rerank → (multi-hop) → generate.

        Returns a dict with keys:
            answer, query, rewritten_query, contexts, hops
        """
        # 1. Query rewriting
        rewritten = self.rewriter.rewrite(query) if use_rewriter else query

        # 2. Retrieval (hybrid)
        hits = self._retrieve(rewritten)

        # 3. Re-ranking
        chunks_by_id = {c.chunk_id: c for c in self.chunk_store.all_chunks()}
        if use_reranker and hits:
            hits = self.reranker.rerank(rewritten, hits, chunks_by_id, self.cfg.top_k)
        else:
            hits = hits[: self.cfg.top_k]

        contexts = self._hits_to_contexts(hits)
        combined_context = " ".join(c.chunk.text[:300] for c in contexts)
        hops = 0

        # 4. Multi-hop (optional additional retrieval rounds)
        if use_multihop:
            for hop in range(self.cfg.max_hops):
                if not self.multihop.needs_another_hop(query, combined_context):
                    break
                subquery = self.multihop.generate_subquery(query, combined_context)
                log.info(f"[MultiHop] Hop {hop+1}: '{subquery}'")
                extra_hits = self._retrieve(subquery)
                if use_reranker and extra_hits:
                    extra_hits = self.reranker.rerank(
                        subquery, extra_hits, chunks_by_id, top_k=2
                    )
                extra_contexts = self._hits_to_contexts(extra_hits[:2])
                contexts.extend(extra_contexts)
                combined_context += " ".join(c.chunk.text[:200] for c in extra_contexts)
                hops += 1

        # Deduplicate contexts
        seen_ids: set[str] = set()
        unique_contexts: list[RetrievedContext] = []
        for ctx in contexts:
            if ctx.chunk.chunk_id not in seen_ids:
                seen_ids.add(ctx.chunk.chunk_id)
                unique_contexts.append(ctx)

        # 5. Answer generation
        answer = self.generator.generate(query, unique_contexts[: self.cfg.top_k])

        return {
            "answer": answer,
            "query": query,
            "rewritten_query": rewritten,
            "contexts": [
                {
                    "chunk_id": c.chunk.chunk_id,
                    "matched_question": c.matched_question,
                    "score": round(c.score, 4),
                    "source_url": c.chunk.source_url,
                    "snippet": c.chunk.text[:200] + "...",
                }
                for c in unique_contexts[: self.cfg.top_k]
            ],
            "hops": hops,
        }
# Paper Files — Enhanced QuIM-RAG

## File Structure

| File | Section | Status |
|---|---|---|
| `01_title_abstract.md` | Title + Abstract | Written — fill in metric values after experiments |
| `02_introduction.md` | I. Introduction | Complete |
| `03_related_work.md` | II. Related Work | Complete |
| `04_methodology.md` | III. Methodology | Complete |
| `05_experimental_setup.md` | IV. Experimental Setup | Written — fill in dataset stats + hardware |
| `06_results.md` | V. Results | Written — fill in [X] values after experiments |
| `07_discussion_conclusion.md` | VI. Discussion + VII. Conclusion + References | Complete |

## What You Need to Fill In

### Before Submission:
1. **Your name, affiliation, email** — in `01_title_abstract.md`
2. **Dataset statistics** — Table I in `05_experimental_setup.md`
3. **Hardware description** — Section IV-F in `05_experimental_setup.md`
4. **All [X] values in results tables** — run experiments first
5. **Acknowledgments** — in `07_discussion_conclusion.md`

### To Get the [X] Values:
Run `main_openrouter.py` with your API key, then trigger evaluation.
Or run the Kaggle/Colab notebook `quim_rag_colab.ipynb` cells 18-24.

## Target Journals/Conferences

| Venue | Type | Deadline | Notes |
|---|---|---|---|
| IEEE Access | Journal | Rolling | Same venue as base paper, open access |
| ACM SIGIR | Conference | ~Feb | Top IR venue, competitive |
| EMNLP Findings | Conference | ~May | Good for NLP extensions |
| EACL | Conference | ~Oct | European ACL, good acceptance rate |
| ECIR | Conference | ~Nov | Information Retrieval focused |

## Citation for Base Paper

```bibtex
@article{saha2024quimrag,
  title={QuIM-RAG: Advancing Retrieval-Augmented Generation With Inverted
         Question Matching for Enhanced QA Performance},
  author={Saha, Binita and Saha, Utsha and Malik, Muhammad Zubair},
  journal={IEEE Access},
  volume={12},
  pages={185401--185410},
  year={2024},
  publisher={IEEE},
  doi={10.1109/ACCESS.2024.3513155}
}
```

## Your Paper BibTeX Template

```bibtex
@article{yourname2025enhanced,
  title={Enhanced QuIM-RAG: Extending Question-to-Question Inverted Index
         Matching with Hybrid Retrieval, Cross-Encoder Re-Ranking, and
         Dynamic Corpus Management for Domain-Specific Question Answering},
  author={[Your Name] and [Co-author]},
  journal={[Target Journal]},
  year={2025},
  note={Under review}
}
```

## VI. DISCUSSION

### A. Impact of Query Rewriting

The query rewriting module demonstrates the most significant impact on
Answer Relevance for short queries. In the original QuIM-RAG system, a
query such as "CS requirements" produces an embedding vector that may
not align well with generated questions like "What are the core course
requirements for the Computer Science B.S. degree at NDSU?" despite
referring to the same information. The semantic gap between a two-word
query and a full generated question can be substantial in the embedding
space, even for semantically equivalent content.

Query rewriting bridges this gap by expanding the query into a full,
specific question before embedding. The rewritten query "What are the
core course requirements for the Computer Science B.S. degree?" aligns
much more closely with the generated question index, improving retrieval
recall for short-query scenarios.

An important design decision is the threshold for triggering rewriting
(≤10 words). Queries longer than this threshold are typically already
specific enough for effective retrieval, and rewriting them risks
introducing semantic drift — the LLM may subtly change the query's
meaning during rewriting. The 10-word threshold was chosen empirically
to balance rewriting benefit against drift risk.

### B. Complementarity of Dense and Sparse Retrieval

The hybrid retrieval results confirm the well-established complementarity
of dense and sparse retrieval. Dense retrieval (QuIM inverted index)
excels at semantic similarity matching — it correctly retrieves chunks
about "career advising services" when the query asks about "job search
help", capturing the semantic equivalence. However, it can fail for
queries containing specific identifiers such as course codes ("CSCI 336"),
building names ("Ceres Hall"), or phone numbers ("701-231-7111"), where
the exact string match is more informative than semantic similarity.

BM25 handles these exact keyword queries naturally through term frequency
and inverse document frequency weighting. The RRF fusion consistently
outperforms either approach alone, confirming that the two retrieval
paradigms capture complementary relevance signals.

The equal weighting (alpha=0.5) between dense and sparse retrieval was
chosen as a reasonable default. Domain-specific tuning of this parameter
may yield further improvements — domains with more keyword-heavy queries
(e.g., legal or medical codes) may benefit from higher sparse weight,
while domains with more semantic queries may benefit from higher dense weight.

### C. Cross-Encoder Re-Ranking Precision

Cross-encoder re-ranking consistently improves Context Precision by
ensuring that the top-3 chunks passed to generation are the most relevant
available. The key advantage of cross-encoders over bi-encoders for
re-ranking is their ability to model fine-grained query-document
interactions through full attention between all query and document tokens.

A bi-encoder independently encodes "What is the phone number of the
Career and Advising Center?" and a chunk containing "The Career and
Advising Center is located at 306 Ceres Hall. Phone: 701-231-7111."
The cross-encoder, by contrast, can attend to the specific token
"phone number" in the query while processing the chunk, directly
identifying the relevant sentence.

The latency overhead of cross-encoder re-ranking (~0.3 seconds for
top-10 candidates) is acceptable for most QA applications. For
latency-critical deployments, the number of re-ranked candidates can
be reduced or re-ranking can be disabled entirely.

### D. Multi-Hop Reasoning Effectiveness

The multi-hop reasoning loop shows the most significant improvement
for complex, multi-faceted questions. For simple factoid questions
(e.g., "What is the phone number of the financial aid office?"),
the first retrieval pass typically surfaces sufficient context, and
the multi-hop check correctly identifies this and skips additional
retrieval rounds.

For complex questions (e.g., "What are the prerequisites for CSCI 366
and what is the minimum GPA required for the CS major?"), the first
retrieval pass may surface information about prerequisites but miss
the GPA requirement, or vice versa. The multi-hop loop detects this
insufficiency and generates a targeted sub-question to retrieve the
missing information.

The word overlap heuristic for sufficiency detection is simple but
effective for the university domain. More sophisticated sufficiency
detection — for example, using an LLM to assess whether the context
is sufficient to answer the query — could further improve multi-hop
performance at the cost of additional LLM calls.

### E. Dynamic Corpus Update in Practice

The dynamic corpus update mechanism addresses a critical practical
limitation of the original QuIM-RAG system. University websites
update their content every semester — course descriptions change,
new programs are added, contact information is updated, and deadlines
shift. Without incremental updates, the RAG system's knowledge becomes
stale within weeks of deployment.

The surgical re-indexing approach reduces update time by approximately
[X]x compared to full re-indexing by processing only changed documents.
The hash-based change detection ensures that unchanged documents are
never re-processed, even if they are re-crawled.

One limitation of the current implementation is that the prototype
index must be fully rebuilt after each update, as K-Means clustering
is not incrementally updatable. For very large corpora, this rebuild
cost may become significant. Future work could explore incremental
prototype update strategies that avoid full K-Means refitting.

### F. Limitations

**LLM Quality Dependency:** The quality of generated questions depends
heavily on the LLM used. Free models (Nemotron, Gemma) may produce
lower-quality questions than GPT-4 for complex technical content,
particularly for highly specialized domain terminology. Lower-quality
questions reduce the effectiveness of the QuIM matching mechanism.

**Manual Review Gap:** The original QuIM-RAG paper emphasizes a manual
review process for generated questions, conducted by two researchers
to verify factual accuracy and contextual relevance. Our implementation
does not automate this review step, which may allow low-quality or
inaccurate questions to enter the index.

**Prototype Index Rebuild:** After each document update, the prototype
index is fully rebuilt via K-Means refitting. For corpora with thousands
of documents, this rebuild cost may become a bottleneck for frequent
updates.

**Feedback Loop Cold Start:** The contrastive feedback loop requires
accumulated user interactions to show improvement. In a fresh deployment
with no prior feedback data, the embedding model is not fine-tuned and
the feedback loop provides no benefit. A minimum of 10 positive feedback
samples is required before fine-tuning is triggered.

**Evaluation LLM Bias:** LLM-based evaluation metrics (Faithfulness,
Answer Relevance, Context Precision, Harmfulness) are computed using
the same LLM used for generation. This introduces potential bias, as
the evaluation LLM may be more lenient toward outputs from models with
similar training distributions. Future work should explore using a
different, independent LLM for evaluation.

---

## VII. CONCLUSION

This paper presented Enhanced QuIM-RAG, a comprehensive extension of the
QuIM-RAG framework that addresses its key architectural limitations through
six targeted contributions. Starting from the strong foundation of
Question-to-question Inverted Index Matching with prototype-quantized
embeddings, we systematically extended the architecture to handle short
and ambiguous queries (query rewriting), exact keyword queries (hybrid
BM25+dense retrieval with RRF), complex multi-step questions (multi-hop
reasoning), and real-world knowledge freshness requirements (dynamic
corpus update with surgical re-indexing). We further improved retrieval
precision through cross-encoder re-ranking and established a continuous
improvement mechanism through the contrastive feedback loop.

Experimental results demonstrate consistent improvements across all
evaluation metrics compared to both traditional RAG and the QuIM-RAG
baseline, while maintaining a Harmfulness score of 0.0 across all
configurations. The ablation study confirms the individual contribution
of each extension, with query rewriting showing the largest impact on
Answer Relevance, hybrid retrieval on Context Precision, and re-ranking
on BERTScore F1.

Our implementation supports free open-source LLMs via OpenRouter and
Ollama, making the system accessible for resource-constrained research
environments without commercial API dependencies. The complete
implementation is available as a Python package and Jupyter notebook
for Google Colab and Kaggle environments.

### Future Work

Several directions for future work emerge from this study:

**Automated Quality Review:** Developing an automated pipeline for
reviewing and filtering generated questions, potentially using a
separate LLM as a quality judge, would eliminate the manual review
bottleneck and enable fully automated corpus construction.

**Incremental Prototype Updates:** Developing incremental K-Means
update strategies that avoid full refitting after each document update
would reduce the dynamic update overhead for large corpora.

**Adaptive Retrieval:** Developing a learned model to predict whether
query rewriting, multi-hop reasoning, or additional retrieval rounds
are needed for a given query would reduce unnecessary LLM calls and
improve system efficiency.

**Cross-Domain Evaluation:** Evaluating Enhanced QuIM-RAG on corpora
from domains beyond university administration — such as medical
guidelines, legal documents, or technical documentation — would
establish the generalizability of our extensions.

**Multilingual Extension:** Extending the system to support multilingual
corpora and queries, leveraging multilingual embedding models such as
mE5 or LaBSE, would broaden the system's applicability to non-English
domains.

**User Study:** Conducting a comprehensive user study to assess user
satisfaction, perceived answer quality, and system usability in
real-world deployment would complement the automated metric evaluation
with human judgment.

---

## ACKNOWLEDGMENTS

[Add your acknowledgments here — funding sources, compute resources,
advisors, dataset contributors, etc.]

---

## REFERENCES

[1] T. B. Brown et al., "Language models are few-shot learners," in
*Proc. Adv. Neural Inf. Process. Syst.*, 2020, pp. 1877–1901.

[2] A. Chowdhery et al., "PaLM: Scaling language modeling with pathways,"
*J. Mach. Learn. Res.*, vol. 24, no. 240, pp. 1–113, 2023.

[3] A. Radford et al., "Language models are unsupervised multitask
learners," *OpenAI Blog*, vol. 1, no. 8, p. 9, 2019.

[4] A. Vaswani et al., "Attention is all you need," in *Proc. Adv.
Neural Inf. Process. Syst.*, vol. 30, 2017.

[5] F. Yang et al., "Empower large language model to perform better on
industrial domain-specific question answering," 2023, arXiv:2305.11541.

[6] Z. Ji et al., "Survey of hallucination in natural language generation,"
*ACM Comput. Surveys*, vol. 55, no. 12, pp. 1–38, Dec. 2023.

[7] N. Kandpal et al., "Large language models struggle to learn long-tail
knowledge," in *Proc. Int. Conf. Mach. Learn.*, 2023, pp. 15696–15707.

[8] M. U. Hadi et al., "A survey on large language models: Applications,
challenges, limitations, and practical usage," *Authorea Preprints*, 2023.

[9] T. B. Brown et al., "Language models are few-shot learners," in
*Proc. Adv. Neural Inf. Process. Syst.*, 2020, pp. 1877–1901.

[10] J. Kirkpatrick et al., "Overcoming catastrophic forgetting in neural
networks," *Proc. Nat. Acad. Sci. USA*, vol. 114, no. 13, pp. 3521–3526,
2017.

[11] O. Ovadia et al., "Fine-tuning or retrieval? Comparing knowledge
injection in LLMs," 2023, arXiv:2312.05934.

[12] P. Lewis et al., "Retrieval-augmented generation for knowledge-intensive
NLP tasks," in *Proc. Adv. Neural Inf. Process. Syst.*, 2020, pp. 9459–9474.

[13] Y. Gao et al., "Retrieval-augmented generation for large language
models: A survey," 2023, arXiv:2312.10997.

[14] B. Saha, U. Saha, and M. Z. Malik, "QuIM-RAG: Advancing
retrieval-augmented generation with inverted question matching for enhanced
QA performance," *IEEE Access*, vol. 12, pp. 185401–185410, 2024.

[15] J. Devlin et al., "BERT: Pre-training of deep bidirectional transformers
for language understanding," in *Proc. NAACL*, 2019, pp. 4171–4186.

[16] A. Radford et al., "Language models are unsupervised multitask
learners," *OpenAI Blog*, 2019.

[17] H. Touvron et al., "Llama 2: Open foundation and fine-tuned chat
models," 2023, arXiv:2307.09288.

[18] J. Hoffmann et al., "Training compute-optimal large language models,"
2022, arXiv:2203.15556.

[19] P. Rajpurkar et al., "SQuAD: 100,000+ questions for machine
comprehension of text," in *Proc. EMNLP*, 2016, pp. 2383–2392.

[20] M. Joshi et al., "TriviaQA: A reading comprehension dataset containing
650K question-answer-evidence triples," in *Proc. ACL*, 2017, pp. 1601–1611.

[21] T. Kwiatkowski et al., "Natural questions: A benchmark for question
answering research," *Trans. Assoc. Comput. Linguistics*, vol. 7, pp.
452–466, 2019.

[22] N. Guha et al., "LegalBench: A collaboratively built benchmark for
measuring legal reasoning in large language models," 2023, arXiv:2308.11462.

[23] D. Jin et al., "What disease does this patient have? A large-scale
open domain question answering dataset from medical exams," *Appl. Sci.*,
vol. 11, no. 14, p. 6421, 2021.

[24] S. Ruder and A. Sil, "Multi-domain multilingual question answering,"
in *Proc. EMNLP Tutorial Abstr.*, 2021, pp. 17–21.

[25] K. Guu et al., "REALM: Retrieval-augmented language model pre-training,"
in *Proc. Int. Conf. Mach. Learn.*, 2020, pp. 3929–3938.

[26] G. Izacard and E. Grave, "Leveraging passage retrieval with generative
models for open domain question answering," in *Proc. EACL*, 2021, pp.
874–880.

[27] L. Gao et al., "Precise zero-shot dense retrieval without relevance
labels," in *Proc. ACL*, 2023, pp. 1762–1777.

[28] Z. Jiang et al., "Active retrieval augmented generation," in *Proc.
EMNLP*, 2023, pp. 7969–7992.

[29] A. Asai et al., "Self-RAG: Learning to retrieve, generate, and
critique through self-reflection," 2023, arXiv:2310.11511.

[30] P. Lewis et al., "PAQ: 65 million probably-asked questions and what
you can do with them," *Trans. Assoc. Comput. Linguistics*, vol. 9, pp.
1098–1115, 2021.

[31] V. Sharma and V. Raman, "A reliable knowledge processing framework
for combustion science using foundation models," 2023, arXiv:2401.00544.

[32] S. Campese et al., "QUADRo: Dataset and models for question-answer
database retrieval," 2023, arXiv:2304.01003.

[33] S. Robertson and H. Zaragoza, "The probabilistic relevance framework:
BM25 and beyond," *Found. Trends Inf. Retr.*, vol. 3, no. 4, pp. 333–389,
2009.

[34] V. Karpukhin et al., "Dense passage retrieval for open-domain question
answering," in *Proc. EMNLP*, 2020, pp. 6769–6781.

[35] L. Ma et al., "Fine-tuning LLaMA for multi-stage text retrieval,"
2023, arXiv:2310.08319.

[36] J. Lin and X. Ma, "A few brief notes on DeepImpact, COIL, and a
conceptual framework for information retrieval techniques," 2021,
arXiv:2106.14807.

[37] S. Luan et al., "Sparse, dense, and attentional representations for
text retrieval," *Trans. Assoc. Comput. Linguistics*, vol. 9, pp. 329–345,
2021.

[38] G. V. Cormack, C. L. A. Clarke, and S. Buettcher, "Reciprocal rank
fusion outperforms condorcet and individual rank learning methods," in
*Proc. ACM SIGIR*, 2009, pp. 758–759.

[39] T. Formal et al., "SPLADE: Sparse lexical and expansion model for
first stage ranking," in *Proc. ACM SIGIR*, 2021, pp. 2288–2292.

[40] R. Nogueira and K. Cho, "Passage re-ranking with BERT," 2019,
arXiv:1901.04085.

[41] R. Nogueira et al., "Document ranking with a pretrained sequence-to-
sequence model," in *Proc. EMNLP Findings*, 2020, pp. 708–718.

[42] L. Hofstätter et al., "Efficiently teaching an effective dense
retriever with balanced topic aware sampling," in *Proc. ACM SIGIR*, 2021,
pp. 113–122.

[43] N. Reimers and I. Gurevych, "Sentence-BERT: Sentence embeddings using
siamese BERT-networks," in *Proc. EMNLP*, 2019, pp. 3982–3992.

[44] M. Kulkarni et al., "Reinforcement learning for optimizing RAG for
domain chatbots," 2024, arXiv:2401.06800.

[45] Q. Yang et al., "HotpotQA: A dataset for diverse, explainable
multi-hop question answering," in *Proc. EMNLP*, 2018, pp. 2369–2380.

[46] Q. Yang et al., "HotpotQA: A dataset for diverse, explainable
multi-hop question answering," in *Proc. EMNLP*, 2018, pp. 2369–2380.

[47] H. Trivedi et al., "MuSiQue: Multihop questions via single-hop
question composition," *Trans. Assoc. Comput. Linguistics*, vol. 10, pp.
539–554, 2022.

[48] X. Ho et al., "Constructing a multi-hop QA dataset for comprehensive
evaluation of reasoning steps," in *Proc. COLING*, 2020, pp. 6609–6625.

[49] H. Trivedi et al., "Interleaving retrieval with chain-of-thought
reasoning for knowledge-intensive multi-step questions," in *Proc. ACL*,
2023, pp. 10014–10037.

[50] Z. Shao et al., "Enhancing retrieval-augmented large language models
with iterative retrieval-generation synergy," 2023, arXiv:2305.15294.

[51] X. Xiong et al., "Answering complex open-domain questions with
multi-hop dense retrieval," in *Proc. ICLR*, 2021.

[52] I. Siragusa and R. Pirrone, "Conditioning ChatGPT for information
retrieval: The UniPA-GPT case study," in *Proc. NL4AI Workshop*, 2023.

[53] S. Mitchell et al., "Fast model editing at scale," in *Proc. ICLR*,
2022.

[54] J. Lyu et al., "CRUD-RAG: A comprehensive Chinese benchmark for
retrieval-augmented generation of large language models," 2024,
arXiv:2401.17043.

[55] N. Muennighoff et al., "MTEB: Massive text embedding benchmark,"
2022, arXiv:2210.07316.

[56] T. Chen et al., "A simple framework for contrastive learning of
visual representations," in *Proc. Int. Conf. Mach. Learn.*, 2020, pp.
1597–1607.

[57] N. Reimers and I. Gurevych, "Augmented SBERT: Data augmentation
method for improving bi-encoders for pairwise sentence scoring tasks,"
in *Proc. NAACL*, 2021, pp. 296–310.

[58] K. Papineni et al., "BLEU: A method for automatic evaluation of
machine translation," in *Proc. ACL*, 2002, pp. 311–318.

[59] S. Banerjee and A. Lavie, "METEOR: An automatic metric for MT
evaluation with improved correlation with human judgments," in *Proc.
ACL Workshop*, 2005, pp. 65–72.

[60] C.-Y. Lin, "ROUGE: A package for automatic evaluation of summaries,"
in *Proc. ACL Workshop*, 2004, pp. 74–81.

[61] T. Zhang et al., "BERTScore: Evaluating text generation with BERT,"
in *Proc. ICLR*, 2020.

[62] S. Es et al., "RAGAS: Automated evaluation of retrieval augmented
generation," 2023, arXiv:2309.15217.

[63] N. Muennighoff et al., "MTEB: Massive text embedding benchmark,"
2022, arXiv:2210.07316.

## II. RELATED WORK

### A. Large Language Models for Question Answering

The transformer architecture introduced by Vaswani et al. [4] laid the
foundation for modern LLMs by enabling parallel sequence processing through
self-attention mechanisms. Subsequent scaling of transformer models — from
BERT [15] and GPT-2 [16] to GPT-3 [1], GPT-4, LLaMA-2 [17], and LLaMA-3 —
demonstrated that model capability scales predictably with parameter count,
training data volume, and compute budget [18].

For question answering specifically, LLMs have been evaluated across a wide
spectrum of benchmarks including SQuAD [19], TriviaQA [20], Natural Questions
[21], and domain-specific benchmarks in law [22], medicine [23], and education
[24]. While LLMs achieve near-human performance on many open-domain QA
benchmarks, their performance degrades significantly on domain-specific tasks
requiring specialized knowledge not well-represented in general training
corpora [8]. This performance gap motivates the development of domain-adapted
QA systems.

Two principal adaptation strategies have been explored. Fine-tuning [9]
involves continued training on domain-specific data, which can substantially
improve performance but requires significant computational resources, labeled
data, and risks catastrophic forgetting of general capabilities [10], [11].
Prompt engineering and in-context learning [1] leverage the few-shot learning
capabilities of large models but are limited by context window size and cannot
access information beyond what is provided in the prompt.

### B. Retrieval-Augmented Generation

RAG was formally introduced by Lewis et al. [12] as a framework combining
a parametric generator (LLM) with a non-parametric retrieval component
(dense passage index). The retrieval component uses a bi-encoder architecture
to independently encode queries and documents into a shared embedding space,
enabling efficient maximum inner product search (MIPS) for retrieval.

Subsequent work has explored numerous variations of the RAG paradigm.
REALM [25] introduced retrieval-augmented language model pre-training, jointly
training the retriever and generator. FiD (Fusion-in-Decoder) [26] proposed
encoding each retrieved passage independently and fusing them in the decoder,
improving multi-passage reasoning. RAG-Token and RAG-Sequence [12] explored
different granularities of retrieval integration into the generation process.

More recent work has focused on improving retrieval quality within RAG systems.
HyDE (Hypothetical Document Embeddings) [27] generates a hypothetical document
answering the query and uses its embedding for retrieval, bridging the
query-document semantic gap. FLARE [28] introduces forward-looking active
retrieval, triggering retrieval only when the model's generation confidence
falls below a threshold. Self-RAG [29] trains the model to decide when to
retrieve, what to retrieve, and how to use retrieved passages through
self-reflection tokens.

Survey work by Gao et al. [13] categorizes RAG approaches into naive RAG,
advanced RAG, and modular RAG, identifying information dilution and
hallucination as the two primary challenges facing current RAG systems —
the same challenges that motivated QuIM-RAG [14] and our extensions.

### C. Question-Based Retrieval

The idea of matching queries against pre-generated questions rather than raw
document passages was explored in the PAQ (Probably Asked Questions) framework
[30]. PAQ generated 65 million question-answer pairs from Wikipedia and
demonstrated that QA-pair retrieval using the RePAQ retriever outperforms
passage retrieval for factoid questions. The key insight is that questions
and queries share the same linguistic form, reducing the semantic gap inherent
in query-to-passage matching.

QuIM-RAG [14] extended this idea to the RAG setting with two key innovations:
(1) generating questions from document chunks rather than from Wikipedia
passages, enabling application to arbitrary domain corpora, and (2) combining
question-based retrieval with prototype-quantized inverted indexing for
efficient retrieval. Our work builds directly on QuIM-RAG, extending its
architecture to address the limitations identified in Section I-D.

Related work on question generation for retrieval includes [31], which
demonstrated that LLM-generated questions from document chunks improve
retrieval precision in RAG systems, and [32], which explored question
generation as a data augmentation strategy for low-resource QA.

### D. Hybrid Retrieval

The complementarity of sparse (BM25) and dense (embedding-based) retrieval
has been extensively studied. BM25 [33] is a probabilistic retrieval model
based on term frequency and inverse document frequency that excels at exact
keyword matching. Dense retrieval [34] captures semantic similarity through
learned embedding representations but can miss exact keyword matches due to
tokenization and embedding space properties.

Hybrid retrieval combining both approaches consistently outperforms either
alone [35]. Approaches to fusion include linear interpolation of scores [36],
learned fusion weights [37], and parameter-free methods such as Reciprocal
Rank Fusion (RRF) [38]. RRF, proposed by Cormack et al. [38], computes a
combined score as the sum of reciprocal ranks from each retrieval system:

```
RRF(d) = Σ 1/(k + rank_r(d))
          r
```

where k is a smoothing constant (typically 60) and rank_r(d) is the rank of
document d in retrieval system r. RRF is parameter-free, robust to score
distribution differences between retrieval systems, and has been shown to
match or outperform learned fusion methods in many settings [38].

In the context of RAG, hybrid retrieval has been applied in systems such as
BM25+DPR [35] and SPLADE+DPR [39]. Our work applies hybrid retrieval
specifically to the QuIM question index, combining BM25 over raw chunk text
with dense retrieval over the generated question embeddings.

### E. Re-Ranking

Re-ranking is a two-stage retrieval approach where an initial retrieval stage
(typically a fast bi-encoder) retrieves a candidate set, and a more expensive
but accurate re-ranking model scores the candidates for final selection.
Cross-encoder re-rankers [40] process query and document jointly through a
transformer, enabling full attention interaction between query and document
tokens. This joint processing captures fine-grained relevance signals that
bi-encoders miss due to independent encoding.

MonoBERT [40] demonstrated that BERT-based cross-encoders substantially
improve retrieval precision over bi-encoder baselines on MSMARCO and TREC
benchmarks. Subsequent work has explored more efficient cross-encoder
architectures [41] and distillation of cross-encoder knowledge into bi-encoders
[42]. The ms-marco-MiniLM family [43] provides efficient cross-encoders trained
on the MSMARCO passage ranking dataset, offering strong re-ranking performance
with reduced inference latency compared to full BERT-large models.

In RAG systems, re-ranking has been shown to improve answer quality by ensuring
that the most relevant chunks are passed to the generation stage [44]. Our work
integrates cross-encoder re-ranking as a post-retrieval, pre-generation stage
in the Enhanced QuIM-RAG pipeline.

### F. Multi-Hop Question Answering

Multi-hop QA requires reasoning over multiple documents or passages to answer
questions that cannot be answered from a single source [45]. Datasets such as
HotpotQA [46], MuSiQue [47], and 2WikiMultiHopQA [48] have driven research
into multi-hop reasoning architectures.

In the RAG setting, multi-hop retrieval has been explored through iterative
approaches. IRCoT [49] interleaves retrieval with chain-of-thought reasoning,
retrieving additional passages at each reasoning step. ITRG [50] proposes
iterative retrieval-generation synergy, using intermediate generation outputs
to guide subsequent retrieval. MDR [51] uses dense retrieval with multi-hop
reasoning chains to navigate through document graphs.

Our multi-hop implementation follows a simpler but effective approach: after
initial retrieval, if the accumulated context is deemed insufficient (based on
query-context word overlap and context length heuristics), an LLM generates
a targeted sub-question, and an additional retrieval round is performed. This
approach is computationally efficient and does not require specialized training.

### G. Dynamic Knowledge Management in RAG

Maintaining up-to-date knowledge bases in RAG systems is an active research
area. The simplest approach — periodic full re-indexing — is computationally
expensive and introduces downtime. Incremental indexing approaches [52] add
new documents without modifying existing index entries but do not handle
document updates or deletions.

Retrieval-augmented editing [53] explores modifying factual knowledge in RAG
systems by updating specific index entries. CRUD-RAG [54] proposes a framework
for create, read, update, and delete operations on RAG knowledge bases.
Our surgical re-indexing approach extends these ideas with chunk-level hash
diffing for minimal computational overhead, enabling efficient updates when
source documents change.

The paper's future work section [14] explicitly identifies dynamic corpus
updates as a planned extension: "Given that university websites frequently
update their content every semester, we are planning to design a content
retrieval mechanism that updates its corpora every four months." Our work
directly implements this planned extension.

### H. Embedding Model Fine-Tuning for Retrieval

Fine-tuning embedding models for domain-specific retrieval has been shown to
substantially improve retrieval quality [55]. Contrastive learning approaches
train embedding models to bring query and relevant document embeddings closer
while pushing irrelevant document embeddings apart [56].

MultipleNegativesRankingLoss [57], implemented in the sentence-transformers
library, is a particularly effective contrastive loss for retrieval fine-tuning.
Given a batch of (query, positive_document) pairs, it treats all other
documents in the batch as negatives, computing:

```
Loss = -log(exp(sim(q, d⁺)) / Σᵢ exp(sim(q, dᵢ)))
```

This in-batch negative sampling strategy is computationally efficient and
has been shown to produce strong retrieval models with relatively small
amounts of training data [57].

Our feedback loop collects positive (query, accepted_chunk) pairs from user
interactions and uses them to fine-tune the BAAI/bge-large-en-v1.5 embedding
model, continuously improving retrieval alignment with user preferences.

### I. Evaluation of RAG Systems

Evaluating RAG systems requires metrics that assess both retrieval quality
and generation quality. Traditional NLP metrics such as BLEU [58], METEOR [59],
and ROUGE [60] are designed for machine translation and summarization tasks
and do not adequately capture the semantic accuracy required for QA evaluation.

BERTScore [61] addresses this limitation by computing token-level cosine
similarity between generated and reference text using contextual BERT
embeddings, capturing semantic equivalence beyond surface-level n-gram overlap.
RAGAS [62] provides a framework specifically designed for RAG evaluation,
computing Faithfulness (grounding of generated claims in retrieved context),
Answer Relevance (appropriateness of the answer to the question), and Context
Precision (relevance of retrieved context to the question) using LLM-based
evaluation without requiring human annotations.

Our evaluation framework implements all metrics from the original QuIM-RAG
paper plus an additional Harmfulness metric, using free open-source LLMs
(via OpenRouter) for LLM-based metric computation to eliminate commercial
API dependencies.

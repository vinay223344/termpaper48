## IV. EXPERIMENTAL SETUP

### A. Dataset Construction

#### A.1 Corpus Collection

We construct a domain-specific corpus from [describe your target domain —
e.g., "the North Dakota State University (NDSU) academic and career advising
websites"]. Following the methodology of Saha et al. [14], we crawl two
primary sub-domains:

- **[Primary domain 1]:** [URL] — covering [describe content, e.g., course
  descriptions, graduation requirements, academic policies]
- **[Primary domain 2]:** [URL] — covering [describe content, e.g., career
  advising services, internship resources, resume guidance]

The web scraper performs breadth-first traversal from these seed URLs,
collecting all reachable sub-pages within the same domain. HTML noise
(headers, footers, navigation elements, scripts) is removed, and pages
with fewer than 250 characters of extracted text are discarded.

**Table I: Dataset Statistics**

| Metric | [Domain 1] | [Domain 2] | Total |
|---|---|---|---|
| Seed URLs | [X] | [X] | [X] |
| Links scraped | [X] | [X] | [X] |
| Pages collected | [X] | [X] | [X] |
| Total chunks | [X] | [X] | [X] |
| Generated questions | [X] | [X] | [X] |
| Ground truth QA pairs | [X] | [X] | [X] |

#### A.2 Ground Truth Preparation

Ground truth QA pairs are manually curated by [N] researchers following a
structured annotation process:

1. **Content selection:** Relevant content sections are identified from the
   corpus, covering a diverse range of topics including [list topic areas,
   e.g., admissions, course requirements, financial aid, career services].

2. **Question formulation:** For each selected content section, one or more
   natural language questions are formulated that a real user might ask.
   Questions are designed to require specific factual information from the
   corpus rather than general knowledge.

3. **Answer verification:** Reference answers are written based on the
   source content and verified for factual accuracy by a second researcher.
   Each answer is directly linked to its source URL.

4. **Quality filtering:** QA pairs with ambiguous questions, incomplete
   answers, or answers requiring information from multiple sources are
   revised or discarded.

The final ground truth dataset contains [X] QA pairs covering [X] distinct
topics. This dataset is used exclusively for evaluation and is not used
during corpus construction or system training.

### B. Model Configuration

**Table II: Model Configuration**

| Component | Model | Parameters | Source |
|---|---|---|---|
| LLM (generation) | nvidia/nemotron-3-super-120b-a12b | 120B (12B active) | OpenRouter (free) |
| LLM (question gen) | nvidia/nemotron-3-super-120b-a12b | 120B (12B active) | OpenRouter (free) |
| Embedding model | BAAI/bge-large-en-v1.5 | 335M | HuggingFace |
| Cross-encoder | cross-encoder/ms-marco-MiniLM-L-6-v2 | 22M | HuggingFace |
| BERTScore model | roberta-large | 355M | HuggingFace |
| Vector database | ChromaDB | — | Local |
| Sparse retrieval | BM25Okapi (rank-bm25) | — | Local |

**Hyperparameters:**

| Parameter | Value | Description |
|---|---|---|
| Chunk size | 1,000 tokens | TikToken cl100k_base |
| Chunk overlap | 200 characters | Cross-boundary context |
| Number of prototypes | 64 | K-Means clusters |
| Top-k retrieval | 3 | Final chunks for generation |
| Hybrid retrieval candidates | 9 | Before re-ranking |
| RRF constant k | 60 | Smoothing parameter |
| Hybrid alpha | 0.5 | Dense/sparse weight balance |
| Max hops | 2 | Multi-hop iterations |
| Query rewrite threshold | 10 words | Minimum query length |
| Max questions per chunk | 8 | Question generation limit |

### C. Evaluation Metrics

We evaluate Enhanced QuIM-RAG using five metrics that collectively assess
retrieval quality, generation quality, and safety. These metrics are computed
using the same LLM (nvidia/nemotron-3-super-120b-a12b via OpenRouter) for
LLM-based evaluations, eliminating commercial API dependencies.

#### C.1 Faithfulness

Faithfulness measures the degree to which the generated answer is grounded
in the retrieved context, directly measuring hallucination:

```
Faithfulness = Number of verified claims / Total claims made
```

**Computation procedure:**
1. Extract atomic factual claims from the generated answer using an LLM
   (e.g., "The center is at 306 Ceres Hall", "Phone is 701-231-7111").
2. For each claim, query the LLM: "Does the following context support this
   claim? Answer only yes or no."
3. Faithfulness = (number of yes responses) / (total claims).

A score of 1.0 indicates that all claims in the answer are supported by
the retrieved context. A score below 1.0 indicates hallucination.

#### C.2 Answer Relevance

Answer Relevance measures whether the generated answer appropriately addresses
the posed question, following the RAGAS formulation [62]:

```
AR = (1/n) * Σᵢ sim(q, qᵢ)
```

where qᵢ are questions generated from the answer using an LLM, and sim is
the cosine similarity between the embedding of the original question q and
each generated question qᵢ.

**Computation procedure:**
1. Generate n=3 candidate questions from the answer using an LLM.
2. Embed the original question and all generated questions using
   BAAI/bge-large-en-v1.5.
3. Compute cosine similarity between the original question embedding and
   each generated question embedding.
4. AR = mean of these similarities.

A high AR score indicates that the answer directly addresses the question.
A low score indicates that the answer is off-topic or incomplete.

#### C.3 Context Precision

Context Precision measures whether the retrieved context contains primarily
relevant information needed to answer the question:

```
CP = Number of relevant sentences extracted / Total sentences in context
```

**Computation procedure:**
1. Split the retrieved context into individual sentences.
2. For each sentence, query the LLM: "Is the following sentence necessary
   to answer the question? Answer only yes or no."
3. CP = (number of yes responses) / (total sentences).

A high CP score indicates that the retrieval mechanism surfaces focused,
relevant context. A low score indicates information dilution — the retrieved
context contains excessive irrelevant content.

#### C.4 Harmfulness

Harmfulness measures the proportion of claims in the generated answer that
are harmful, offensive, dangerous, or inappropriate:

```
Harmfulness = Number of harmful claims / Total claims made
```

**Computation procedure:**
1. Extract atomic claims from the generated answer (same as Faithfulness).
2. For each claim, query the LLM: "Is the following statement harmful,
   offensive, dangerous, or inappropriate? Answer only yes or no."
3. Harmfulness = (number of yes responses) / (total claims).

A score of 0.0 (ideal) indicates no harmful content. This metric is
particularly important for educational and public-facing QA systems.

#### C.5 BERTScore

BERTScore [61] evaluates the semantic quality of generated text by measuring
token-level cosine similarity between generated and reference text using
contextual RoBERTa-large embeddings:

**BERT-Precision (BERT-P):**
```
P_BERT = (1/|ŷ|) * Σ_{ŷⱼ∈ŷ} max_{yᵢ∈y} cosine_sim(Xᵢ, X̂ⱼ)
```

**BERT-Recall (BERT-R):**
```
R_BERT = (1/|y|) * Σ_{yᵢ∈y} max_{ŷⱼ∈ŷ} cosine_sim(Xᵢ, X̂ⱼ)
```

**BERT-F1:**
```
F_BERT = 2 * (P_BERT * R_BERT) / (P_BERT + R_BERT)
```

where y is the reference answer, ŷ is the generated answer, and Xᵢ, X̂ⱼ
are contextual token embeddings from RoBERTa-large.

Unlike n-gram based metrics (BLEU, ROUGE), BERTScore captures semantic
equivalence — paraphrases of the reference answer receive high scores even
if they share few exact tokens.

### D. Baselines

We compare Enhanced QuIM-RAG against three baselines:

**Baseline 1 — Traditional RAG:**
Standard RAG with direct chunk embedding retrieval. Document chunks are
embedded using BAAI/bge-large-en-v1.5 and stored in ChromaDB. At query
time, the query embedding is matched against chunk embeddings via cosine
similarity, and the top-3 chunks are passed to the LLM for generation.
No question generation, no prototype quantization, no hybrid retrieval,
no re-ranking.

**Baseline 2 — QuIM-RAG (Base Paper):**
The original QuIM-RAG implementation as described in Saha et al. [14],
with question generation, prototype-quantized inverted index, and top-3
question matching. No query rewriting, no hybrid retrieval, no re-ranking,
no multi-hop reasoning.

**Baseline 3 — Enhanced QuIM-RAG (Ours):**
The full Enhanced QuIM-RAG pipeline with all six extensions active.

### E. Ablation Study Design

To isolate the contribution of each extension, we conduct an ablation study
starting from the QuIM-RAG base and incrementally adding each extension:

| Configuration | Extensions Active |
|---|---|
| QuIM-RAG base | None (base paper) |
| + Query Rewriting | Extension 1 |
| + Hybrid Retrieval | Extensions 1-2 |
| + Re-Ranking | Extensions 1-3 |
| + Multi-Hop | Extensions 1-4 |
| + Dynamic Update | Extensions 1-5 |
| + Feedback Loop | Extensions 1-6 (full system) |

Each configuration is evaluated on the full ground truth QA dataset using
all five metrics. Statistical significance is assessed using paired t-tests
with α=0.05.

### F. Implementation Details

The Enhanced QuIM-RAG system is implemented in Python 3.10+ using the
following key libraries:

- **sentence-transformers** (≥2.6.1): Embedding model and cross-encoder
- **chromadb** (≥0.4.22): Persistent vector database
- **rank-bm25** (≥0.2.2): BM25 sparse retrieval
- **scikit-learn** (≥1.4.0): K-Means prototype fitting
- **tiktoken** (≥0.6.0): Token-based text chunking
- **bert-score** (≥0.3.13): BERTScore evaluation
- **openai** (≥1.14.0): OpenRouter API client
- **httpx** (≥0.27.0): HTTP client for OpenRouter connectivity

The system is designed to run without commercial API dependencies using
free models via OpenRouter (nvidia/nemotron-3-super-120b-a12b:free) or
locally via Ollama (llama3.2, mistral). A Jupyter notebook implementation
is provided for Google Colab and Kaggle environments, supporting free T4
GPU acceleration for embedding computation and LLM inference.

All experiments are conducted on [describe your hardware — e.g., "a machine
with an NVIDIA T4 GPU (16GB VRAM), 32GB RAM, and an Intel Xeon processor"].
Embedding computation uses GPU acceleration where available, falling back
to CPU for environments without GPU support.

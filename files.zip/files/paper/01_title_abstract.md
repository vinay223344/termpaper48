# Enhanced QuIM-RAG: Extending Question-to-Question Inverted Index Matching
# with Hybrid Retrieval, Cross-Encoder Re-Ranking, and Dynamic Corpus Management
# for Domain-Specific Question Answering

**Authors:** [Your Name]¹, [Co-author Name]¹
**Affiliation:** ¹Department of Computer Science, [Your University], [City], [Country]
**Corresponding Author:** [your.email@university.edu]
**Submitted to:** [Target Journal/Conference — e.g., IEEE Access / ACM SIGIR / EMNLP]

---

## ABSTRACT

Retrieval-Augmented Generation (RAG) has established itself as a foundational
paradigm for grounding Large Language Model (LLM) responses in external,
domain-specific knowledge, effectively mitigating hallucination and knowledge
staleness without the computational overhead of full model fine-tuning. The
recently proposed QuIM-RAG framework (Saha et al., 2024) advanced this paradigm
by introducing Question-to-question Inverted Index Matching (QuIM) — a novel
retrieval mechanism that generates potential questions from document chunks and
matches user queries against these generated questions using prototype-quantized
embedding vectors stored in an inverted index. While QuIM-RAG demonstrated
substantial improvements over traditional RAG in faithfulness, answer relevance,
and BERTScore metrics on a university knowledge base, several architectural
limitations remain unaddressed: short and ambiguous queries produce suboptimal
embedding matches, dense-only retrieval misses exact keyword queries, single-pass
retrieval fails for complex multi-step questions, and the static corpus design
cannot accommodate real-world knowledge updates without full re-indexing.

In this work, we present **Enhanced QuIM-RAG**, a systematic and comprehensive
extension of the QuIM-RAG architecture that addresses each of these limitations
through six targeted contributions integrated into a unified pipeline. First, we
introduce a **query rewriting module** that employs a pre-retrieval LLM pass to
expand short or colloquial queries into specific, self-contained questions that
better align with the semantic space of the generated question index. Second, we
propose **hybrid retrieval with Reciprocal Rank Fusion (RRF)**, combining the
QuIM dense inverted index with BM25 sparse retrieval to capture both semantic
similarity and exact lexical matches, fused via the parameter-free RRF formula:
score = 1/(k + rank_dense) + 1/(k + rank_sparse) with k=60. Third, we integrate
**cross-encoder re-ranking** using the ms-marco-MiniLM-L-6-v2 model to re-score
top-10 retrieved candidates through full query-document attention interaction,
retaining only the top-3 for generation. Fourth, we implement a **multi-hop
reasoning loop** that iteratively decomposes complex queries into sub-questions,
performing additional retrieval rounds until sufficient context is accumulated.
Fifth, we design a **dynamic corpus update mechanism** with surgical chunk-level
re-indexing, using content hash diffing to detect changes and updating only
affected chunks in ChromaDB and the prototype inverted index, avoiding costly
full re-indexing. Sixth, we establish a **contrastive feedback loop** that logs
user interaction signals and fine-tunes the embedding model using
MultipleNegativesRankingLoss on accepted (query, chunk) pairs, enabling
continuous retrieval improvement from real-world usage.

We evaluate Enhanced QuIM-RAG on a domain-specific university knowledge base
corpus using a comprehensive suite of metrics: BERTScore (Precision, Recall, F1),
Faithfulness (verified claims / total claims), Answer Relevance (cosine similarity
between original and reverse-generated questions), Context Precision (relevant
sentences / total context sentences), and Harmfulness (harmful claims / total
claims). Experimental results demonstrate that our extensions collectively improve
BERTScore F1 by [X]%, Faithfulness by [Y]%, and Answer Relevance by [Z]% over
the QuIM-RAG baseline, while maintaining a Harmfulness score of 0.0 across all
configurations. An ablation study confirms the individual contribution of each
extension to overall system performance. Our implementation supports free
open-source LLMs via OpenRouter (nvidia/nemotron-3-super-120b-a12b) and Ollama,
eliminating commercial API dependencies and making the system accessible for
resource-constrained research environments.

**Index Terms:** Retrieval-Augmented Generation, Question Answering, Inverted
Index Matching, Hybrid Retrieval, Reciprocal Rank Fusion, Cross-Encoder
Re-Ranking, Multi-Hop Reasoning, Dynamic Corpus Update, Large Language Models,
BERTScore, RAGAS, Domain-Specific QA.

## I. INTRODUCTION

### A. Background and Motivation

The emergence of Large Language Models (LLMs) has fundamentally transformed
the landscape of Natural Language Processing (NLP), enabling systems to
understand and generate human-like text with unprecedented fluency and
coherence [1]. Models such as GPT-4, Meta's LLaMA series, Google's Gemma,
and NVIDIA's Nemotron have demonstrated remarkable capabilities across a wide
range of tasks including text summarization, code generation, translation, and
open-domain question answering [2], [3]. These models are trained on massive
corpora spanning billions of tokens, encoding broad world knowledge within
their parameters through the transformer attention mechanism [4].

However, despite their impressive general capabilities, LLMs face fundamental
limitations when deployed for domain-specific question answering (QA) tasks
where accuracy, reliability, and up-to-date information are critical
requirements. Three core challenges consistently emerge in practice:

**Knowledge Staleness:** LLMs are trained on static snapshots of data with
fixed knowledge cutoff dates. They cannot access information published after
training, making them unsuitable for domains where content changes frequently —
such as university course catalogs, medical guidelines, legal regulations, or
corporate policies [5]. A student asking about current enrollment deadlines or
a patient asking about updated treatment protocols cannot rely on a model whose
knowledge may be months or years out of date.

**Hallucination:** LLMs are prone to generating responses that are linguistically
fluent and contextually plausible but factually incorrect — a phenomenon termed
hallucination [6]. This occurs because LLMs generate text by predicting the most
probable next token given prior context, without any mechanism to verify factual
grounding. In high-stakes domains such as healthcare, law, and education,
hallucinated responses can cause serious harm. Studies have shown hallucination
rates of 15-30% in domain-specific QA tasks even for state-of-the-art models [7].

**Domain Specificity:** LLMs trained on general web corpora lack deep coverage
of specialized domains. Niche topics — such as the specific graduation
requirements of a particular university department, the admission criteria of a
specific graduate program, or the contact information of a specific administrative
office — are either absent from training data or represented with insufficient
frequency to be reliably recalled [8].

Two principal strategies have emerged to address these limitations. The first,
**fine-tuning**, involves additional training of a pre-existing LLM on
domain-specific data to optimize it for particular tasks [9]. While effective,
fine-tuning is computationally expensive, requires large amounts of labeled
domain data, and risks catastrophic forgetting — where the model loses
previously learned general knowledge during domain-specific training [10], [11].
The second strategy, **Retrieval-Augmented Generation (RAG)**, augments LLM
generation with dynamically retrieved external knowledge at inference time,
avoiding the costs and risks of fine-tuning while enabling real-time access to
up-to-date domain information [12].

### B. Retrieval-Augmented Generation and Its Limitations

RAG was formally introduced by Lewis et al. [12] as a framework that combines
parametric memory (the LLM's learned weights) with non-parametric memory (a
retrieval index over external documents). At inference time, a user query is
encoded into a vector representation, the most semantically similar document
chunks are retrieved from the index, and these chunks are provided as context
to the LLM for grounded response generation. This approach enables domain
adaptation without fine-tuning, supports real-time knowledge updates by
modifying the retrieval index, and provides source attribution for generated
responses.

Despite these advantages, traditional RAG architectures face two persistent
and well-documented challenges [13]:

**Information Dilution:** When the retrieval mechanism returns chunks that are
only loosely related to the query, the LLM's context window becomes populated
with irrelevant information. This dilutes the signal from truly relevant content,
causing the model to generate responses that are vague, incomplete, or
inconsistent with the most relevant source material. Information dilution is
particularly severe when the corpus is large and topically diverse, as the
retrieval mechanism must distinguish between many superficially similar chunks.

**Hallucination Persistence:** Even with retrieved context, LLMs can hallucinate
when the retrieval mechanism fails to surface the most relevant chunks. If the
context does not contain the answer to the user's question, the LLM may
extrapolate beyond the provided context, generating plausible-sounding but
factually incorrect responses. This is especially problematic for specific
factual queries (e.g., "What is the phone number of the financial aid office?")
where the answer must be retrieved exactly rather than inferred.

Traditional RAG retrieval relies on direct semantic similarity between the user
query embedding and document chunk embeddings. This approach has a fundamental
mismatch: user queries are typically short, conversational, and expressed in
natural language, while document chunks are longer, formal, and structured
around information presentation rather than question answering. The semantic
gap between these two modalities reduces retrieval precision, particularly for
short or ambiguous queries.

### C. The QuIM-RAG Framework

To address the semantic mismatch in traditional RAG retrieval, Saha et al. [14]
proposed QuIM-RAG (Question-to-question Inverted Index Matching), which inverts
the traditional document-to-query matching paradigm. Instead of matching user
queries directly against document chunk embeddings, QuIM-RAG generates a set of
potential questions for each document chunk using an instruction-following LLM.
These generated questions represent the information content of each chunk in
question form — essentially creating a "frequently asked questions" index for
the corpus.

At retrieval time, the user query is matched against this question index rather
than against raw document embeddings. Since both the user query and the indexed
questions are expressed in natural language question form, the semantic gap is
substantially reduced. The most semantically similar generated questions are
identified, and their associated document chunks are retrieved as context for
generation.

QuIM-RAG further introduces prototype-quantized embedding indexing to reduce
retrieval computational complexity. Question embeddings are quantized to the
nearest prototype vector (learned via clustering), and an inverted index maps
each prototype to its associated question embeddings and chunk IDs. This
structure enables efficient retrieval by limiting the search space to the
prototype bucket most similar to the query, rather than scoring all vectors.

Evaluated on a university knowledge base corpus from North Dakota State
University (NDSU), QuIM-RAG demonstrated significant improvements over
traditional RAG: Faithfulness improved from 0.69 to 1.00, Answer Relevance
from 0.79 to 0.99, Context Precision from 0.45 to 0.92, and BERTScore F1
from 0.31 to 0.67 [14]. These results established QuIM-RAG as a strong
baseline for domain-specific QA.

### D. Limitations of QuIM-RAG and Motivation for This Work

Despite its strong performance, the original QuIM-RAG architecture has several
architectural limitations that constrain its applicability in real-world
deployment scenarios:

**Limitation 1 — Short Query Sensitivity:** The query rewriting step is absent
in the original QuIM-RAG. Short, colloquial, or abbreviated queries (e.g.,
"CS requirements", "contact career center", "FAFSA code") produce embedding
vectors that may not align well with the generated question index, even though
the relevant information exists in the corpus. The semantic gap between a
two-word query and a full generated question can be substantial.

**Limitation 2 — Dense-Only Retrieval:** QuIM-RAG relies exclusively on dense
embedding retrieval for question matching. While dense retrieval excels at
semantic similarity, it can fail for exact keyword queries — particularly
queries containing specific identifiers such as course codes (e.g., "CSCI 336"),
building names, phone numbers, or email addresses. Sparse retrieval methods
like BM25 handle these cases naturally through exact term matching.

**Limitation 3 — Single-Pass Retrieval:** The original QuIM-RAG performs a
single retrieval pass per query, returning the top-k most similar question
matches. For complex, multi-faceted questions that require synthesizing
information from multiple document sections (e.g., "What are the prerequisites
for CSCI 366 and when is the next offering?"), a single retrieval pass may
not surface all necessary context.

**Limitation 4 — Static Corpus:** The original QuIM-RAG system does not
address corpus maintenance. University websites, for example, update their
content every semester — new courses are added, contact information changes,
deadlines shift. Without a mechanism for incremental updates, the entire
corpus must be re-indexed periodically, which is computationally expensive
and introduces downtime.

**Limitation 5 — No Feedback Mechanism:** User interactions with the QA
system generate valuable implicit feedback signals. When a user rates an
answer positively, the (query, retrieved chunk) pair represents a high-quality
training example for the embedding model. The original QuIM-RAG does not
leverage these signals for continuous improvement.

**Limitation 6 — Re-Ranking Absent:** After retrieving top-k candidates via
the inverted index, no re-ranking step is applied. The bi-encoder retrieval
model (BAAI/bge-large-en-v1.5) encodes query and document independently,
missing fine-grained interaction signals that a cross-encoder model can
capture by processing query and document jointly.

These limitations motivate the development of Enhanced QuIM-RAG, which
addresses each limitation through a targeted architectural extension while
preserving the core QuIM inverted index matching mechanism that drives
QuIM-RAG's superior performance.

### E. Contributions

This paper makes the following contributions:

1. **Query Rewriting Module (Section III-E):** We introduce a pre-retrieval
   LLM-based query rewriting step that transforms short, ambiguous, or
   colloquial queries into specific, self-contained questions optimized for
   semantic matching against the generated question index. We demonstrate
   that this step significantly improves retrieval recall for short queries
   without degrading performance on longer, well-formed queries.

2. **Hybrid Retrieval with Reciprocal Rank Fusion (Section III-F):** We
   propose combining the QuIM dense inverted index retrieval with BM25 sparse
   retrieval, fusing results via Reciprocal Rank Fusion (RRF). This hybrid
   approach captures both semantic similarity and exact lexical matches,
   improving retrieval coverage for keyword-heavy queries that dense retrieval
   alone misses.

3. **Cross-Encoder Re-Ranking (Section III-G):** We integrate a cross-encoder
   re-ranking stage that re-scores top-10 retrieved candidates using full
   query-document attention interaction, retaining only the top-3 for
   generation. Cross-encoders consistently outperform bi-encoders for
   re-ranking due to their ability to model fine-grained query-document
   interactions.

4. **Multi-Hop Reasoning Loop (Section III-H):** We implement an iterative
   retrieval mechanism that decomposes complex queries into sub-questions,
   performing additional retrieval rounds until sufficient context is
   accumulated. This enables accurate answering of multi-faceted questions
   that require synthesizing information from multiple document sections.

5. **Dynamic Corpus Update with Surgical Re-Indexing (Section III-I):** We
   design a chunk-level update mechanism that uses content hash diffing to
   detect changed documents and surgically updates only affected chunks in
   ChromaDB and the prototype inverted index. This enables real-time knowledge
   freshness without full corpus re-indexing.

6. **Contrastive Feedback Loop (Section III-J):** We establish a user feedback
   collection and embedding fine-tuning pipeline that leverages positive
   (query, accepted chunk) pairs to fine-tune the embedding model using
   MultipleNegativesRankingLoss, enabling continuous retrieval improvement
   from real-world usage signals.

7. **Comprehensive Evaluation Framework (Section IV-C):** We implement all
   evaluation metrics from the original paper (BERTScore, Faithfulness, Answer
   Relevance, Context Precision) plus an additional Harmfulness metric, using
   free open-source LLMs for evaluation to eliminate commercial API
   dependencies.

### F. Paper Organization

The remainder of this paper is organized as follows. Section II reviews related
work on RAG architectures, hybrid retrieval, re-ranking, and dynamic knowledge
management. Section III presents the Enhanced QuIM-RAG architecture in detail,
describing each component and its integration into the unified pipeline.
Section IV describes the experimental setup including dataset construction,
model selection, and evaluation metrics. Section V presents experimental
results including main comparison results and ablation study. Section VI
discusses key findings, limitations, and implications. Section VII concludes
the paper and outlines directions for future work.

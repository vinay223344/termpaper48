"""
quim_rag_ollama.py — QuIM-RAG pipeline using Ollama (100% free, local LLMs)

Drop-in replacement for quim_rag.py but uses Ollama instead of OpenAI.

Setup:
  1. Install Ollama: https://ollama.com/download
  2. Pull a model:
       ollama pull llama3.2        # ~2GB, fast
       ollama pull llama3.1:8b     # ~5GB, better quality
  3. Run: python quim_rag_ollama.py

No API key needed. Everything runs locally.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import chromadb
import ollama
from chromadb.config import Settings
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder, SentenceTransformer

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class OllamaConfig:
    # Ollama models — change to whatever you have pulled
    generator_model: str = "llama3.2"        # ollama pull llama3.2
    question_gen_model: str = "llama3.2"     # same model for question gen

    # Embedding still uses HuggingFace (Ollama embeddings are optional)
    embedding_model: str = "BAAI/bge-large-en-v1.5"
    reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"

    # Chunking
    chunk_size: int = 1000
    chunk_overlap: int = 200

    # Retrieval
    top_k: int = 3
    rrf_k: int = 60
    hybrid_alpha: float = 0.5

    # Multi-hop
    max_hops: int = 2

    # Storage
    chroma_persist_dir: str = "./chroma_db_ollama"
    collection_name: str = "quim_rag_ollama"
    chunk_store_path: str = "./chunk_store_ollama.json"


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    text: str
    source_url: str = ""
    questions: list[str] = field(default_factory=list)


@dataclass
class RetrievedContext:
    chunk: Chunk
    score: float
    matched_question: str


# ---------------------------------------------------------------------------
# Ollama LLM helper
# ---------------------------------------------------------------------------

class OllamaLLM:
    """Thin wrapper around the ollama Python client."""

    def __init__(self, model: str):
        self.model = model
        self._check_model()

    def _check_model(self) -> None:
        try:
            models = [m.model for m in ollama.list().models]
            # strip tag for comparison
            base = self.model.split(":")[0]
            available = [m.split(":")[0] for m in models]
            if base not in available:
                log.warning(
                    f"[Ollama] Model '{self.model}' not found locally. "
                    f"Run: ollama pull {self.model}"
                )
            else:
                log.info(f"[Ollama] Model '{self.model}' is available")
        except Exception as e:
            log.warning(f"[Ollama] Could not connect to Ollama server: {e}")
            log.warning("[Ollama] Make sure Ollama is running: ollama serve")

    def chat(self, prompt: str, temperature: float = 0.1, max_tokens: int = 512) -> str:
        try:
            resp = ollama.chat(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": temperature, "num_predict": max_tokens},
            )
            return resp.message.content.strip()
        except Exception as e:
            log.error(f"[Ollama] Chat failed: {e}")
            raise


# ---------------------------------------------------------------------------
# 1. Corpus ingestion & chunking
# ---------------------------------------------------------------------------

class CorpusIngester:
    def __init__(self, cfg: OllamaConfig):
        self.cfg = cfg
        try:
            import tiktoken
            self._enc = tiktoken.get_encoding("cl100k_base")
        except ImportError:
            self._enc = None

    def _tokenize(self, text: str):
        return self._enc.encode(text) if self._enc else text.split()

    def _detokenize(self, tokens) -> str:
        return self._enc.decode(tokens) if self._enc else " ".join(tokens)

    def chunk_document(self, doc_id: str, text: str, source_url: str = "") -> list[Chunk]:
        tokens = self._tokenize(text)
        chunks: list[Chunk] = []
        step = self.cfg.chunk_size - self.cfg.chunk_overlap // 4

        for i, start in enumerate(range(0, len(tokens), step)):
            end = min(start + self.cfg.chunk_size, len(tokens))
            chunk_text = self._detokenize(tokens[start:end])
            if len(chunk_text.strip()) < 250:
                continue
            chunk_id = hashlib.md5(f"{doc_id}_{i}".encode()).hexdigest()[:12]
            chunks.append(Chunk(chunk_id=chunk_id, doc_id=doc_id,
                                text=chunk_text, source_url=source_url))
            if end >= len(tokens):
                break

        log.info(f"[Ingester] {doc_id}: {len(chunks)} chunks")
        return chunks


# ---------------------------------------------------------------------------
# 2. Question generation (via Ollama)
# ---------------------------------------------------------------------------

QUESTION_GEN_PROMPT = """\
Your task: read the text below and output questions about it.

STRICT OUTPUT FORMAT — output ONLY a JSON array like this example:
["Question one?", "Question two?", "Question three?"]

No markdown, no code fences, no explanation, no preamble.
Start your response with [ and end with ]

Text:
{chunk_text}

JSON array of questions:"""


class QuestionGenerator:
    def __init__(self, cfg: OllamaConfig, llm: OllamaLLM):
        self.cfg = cfg
        self.llm = llm

    def _extract_questions(self, raw: str) -> list[str]:
        # Strategy 1: JSON array anywhere in response
        match = re.search(r"\[.*?\]", raw, re.DOTALL)
        if match:
            try:
                questions = json.loads(match.group())
                if isinstance(questions, list) and questions:
                    return [q.strip() for q in questions if isinstance(q, str) and q.strip()]
            except json.JSONDecodeError:
                pass
        # Strategy 2: strip markdown fences then parse
        cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        if cleaned.startswith("["):
            try:
                questions = json.loads(cleaned)
                if isinstance(questions, list) and questions:
                    return [q.strip() for q in questions if isinstance(q, str) and q.strip()]
            except json.JSONDecodeError:
                pass
        # Strategy 3: quoted strings ending with ?
        quoted = re.findall(r'"([^"]{10,}[?])"', raw)
        if quoted:
            return [q.strip() for q in quoted]
        # Strategy 4: numbered/bulleted lines containing ?
        lines = [
            re.sub(r"^[\d\-\*\.\)]+\s*", "", line).strip()
            for line in raw.splitlines()
            if line.strip() and "?" in line
        ]
        return lines if lines else []

    def generate(self, chunk: Chunk, max_questions: int = 8) -> list[str]:
        prompt = QUESTION_GEN_PROMPT.format(chunk_text=chunk.text[:2000])
        try:
            raw = self.llm.chat(prompt, temperature=0.2, max_tokens=600)
            questions = self._extract_questions(raw)
            if not questions:
                log.warning(f"[QGen] No questions extracted for {chunk.chunk_id}. Raw: {raw[:200]}")
                return []
            return questions[:max_questions]
        except Exception as e:
            log.warning(f"[QGen] Failed for chunk {chunk.chunk_id}: {e}")
            return []


# ---------------------------------------------------------------------------
# 3. Inverted index (ChromaDB)
# ---------------------------------------------------------------------------

class InvertedIndex:
    def __init__(self, cfg: OllamaConfig):
        self.cfg = cfg
        self.embed_model = SentenceTransformer(cfg.embedding_model)
        chroma_client = chromadb.PersistentClient(
            path=cfg.chroma_persist_dir,
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = chroma_client.get_or_create_collection(
            name=cfg.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        log.info(f"[Index] Ready ({self.collection.count()} vectors)")

    def add_chunk(self, chunk: Chunk) -> None:
        if not chunk.questions:
            return
        embeddings = self.embed_model.encode(
            chunk.questions, normalize_embeddings=True
        ).tolist()
        ids, docs, metas, embs = [], [], [], []
        for q_idx, (q, emb) in enumerate(zip(chunk.questions, embeddings)):
            ids.append(f"{chunk.chunk_id}_q{q_idx}")
            docs.append(q)
            metas.append({"chunk_id": chunk.chunk_id, "doc_id": chunk.doc_id,
                          "source_url": chunk.source_url})
            embs.append(emb)
        self.collection.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=embs)

    def query(self, query_text: str, top_k: int = 10) -> list[dict]:
        count = self.collection.count()
        if count == 0:
            return []
        q_emb = self.embed_model.encode([query_text], normalize_embeddings=True).tolist()
        results = self.collection.query(
            query_embeddings=q_emb,
            n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"],
        )
        hits = []
        if results["ids"] and results["ids"][0]:
            for vec_id, doc, meta, dist in zip(
                results["ids"][0], results["documents"][0],
                results["metadatas"][0], results["distances"][0],
            ):
                hits.append({
                    "vec_id": vec_id, "question": doc,
                    "chunk_id": meta["chunk_id"], "doc_id": meta["doc_id"],
                    "source_url": meta.get("source_url", ""),
                    "distance": dist, "score": 1.0 - dist,
                })
        return hits

    def delete_chunk(self, chunk_id: str) -> None:
        results = self.collection.get(where={"chunk_id": chunk_id})
        if results["ids"]:
            self.collection.delete(ids=results["ids"])


# ---------------------------------------------------------------------------
# 4a. Query Rewriting
# ---------------------------------------------------------------------------

REWRITE_PROMPT = """\
Rewrite this question to be more specific and self-contained for searching \
a university knowledge base. Return ONLY the rewritten question, nothing else.

Question: {query}
Rewritten:"""


class QueryRewriter:
    def __init__(self, llm: OllamaLLM):
        self.llm = llm

    def rewrite(self, query: str) -> str:
        if len(query.split()) > 10:
            return query
        try:
            rewritten = self.llm.chat(
                REWRITE_PROMPT.format(query=query), temperature=0.0, max_tokens=80
            )
            log.info(f"[Rewriter] '{query}' → '{rewritten}'")
            return rewritten
        except Exception:
            return query


# ---------------------------------------------------------------------------
# 4b. Hybrid Retrieval (BM25 + Dense via RRF)
# ---------------------------------------------------------------------------

class HybridRetriever:
    def __init__(self, cfg: OllamaConfig, index: InvertedIndex, chunks: list[Chunk]):
        self.cfg = cfg
        self.index = index
        self.chunks_by_id: dict[str, Chunk] = {c.chunk_id: c for c in chunks}
        self.chunk_order = [c.chunk_id for c in chunks]
        if chunks:
            tokenized = [c.text.lower().split() for c in chunks]
            self.bm25 = BM25Okapi(tokenized)
            log.info(f"[BM25] Index built over {len(chunks)} chunks")
        else:
            self.bm25 = None
            log.warning("[BM25] No chunks — BM25 skipped")

    def retrieve(self, query: str, top_k: int) -> list[dict]:
        dense_hits = self.index.query(query, top_k=top_k * 3)
        dense_scores: dict[str, float] = {}
        for rank, hit in enumerate(dense_hits):
            cid = hit["chunk_id"]
            if cid not in dense_scores:
                dense_scores[cid] = 1.0 / (self.cfg.rrf_k + rank + 1)

        sparse_scores: dict[str, float] = {}
        if self.bm25 and self.chunk_order:
            bm25_raw = self.bm25.get_scores(query.lower().split())
            ranked = sorted(enumerate(bm25_raw), key=lambda x: x[1], reverse=True)[:top_k * 3]
            for rank, (idx, _) in enumerate(ranked):
                cid = self.chunk_order[idx]
                sparse_scores[cid] = 1.0 / (self.cfg.rrf_k + rank + 1)

        all_ids = set(dense_scores) | set(sparse_scores)
        fused = sorted(
            [(cid, self.cfg.hybrid_alpha * dense_scores.get(cid, 0)
              + (1 - self.cfg.hybrid_alpha) * sparse_scores.get(cid, 0))
             for cid in all_ids],
            key=lambda x: x[1], reverse=True,
        )

        results = []
        for cid, score in fused[:top_k]:
            chunk = self.chunks_by_id.get(cid)
            if not chunk:
                continue
            matched_q = next((h["question"] for h in dense_hits if h["chunk_id"] == cid),
                             chunk.questions[0] if chunk.questions else "")
            results.append({"chunk_id": cid, "question": matched_q,
                            "score": score, "source_url": chunk.source_url})
        return results


# ---------------------------------------------------------------------------
# 4c. Cross-Encoder Re-Ranking
# ---------------------------------------------------------------------------

class Reranker:
    def __init__(self, cfg: OllamaConfig):
        self.model = CrossEncoder(cfg.reranker_model)
        log.info(f"[Reranker] Loaded {cfg.reranker_model}")

    def rerank(self, query: str, hits: list[dict],
               chunks_by_id: dict[str, Chunk], top_k: int) -> list[dict]:
        pairs = []
        for hit in hits:
            chunk = chunks_by_id.get(hit["chunk_id"])
            text = chunk.text[:512] if chunk else hit.get("question", "")
            pairs.append((query, text))
        scores = self.model.predict(pairs).tolist()
        for hit, score in zip(hits, scores):
            hit["rerank_score"] = score
        reranked = sorted(hits, key=lambda h: h["rerank_score"], reverse=True)
        return reranked[:top_k]


# ---------------------------------------------------------------------------
# 4d. Multi-hop Reasoning
# ---------------------------------------------------------------------------

SUBQUERY_PROMPT = """\
The context below is insufficient to fully answer the question.
Identify ONE specific sub-question that would help complete the answer.
Return ONLY the sub-question, nothing else.

Question: {query}
Partial context: {partial_context}
Sub-question:"""


class MultiHopReasoner:
    def __init__(self, cfg: OllamaConfig, llm: OllamaLLM):
        self.cfg = cfg
        self.llm = llm

    def needs_another_hop(self, query: str, context: str) -> bool:
        overlap = len(set(query.lower().split()) & set(context.lower().split()))
        return overlap < 3 and len(context) < 400

    def generate_subquery(self, query: str, partial_context: str) -> str:
        try:
            return self.llm.chat(
                SUBQUERY_PROMPT.format(query=query, partial_context=partial_context[:600]),
                temperature=0.2, max_tokens=80,
            )
        except Exception:
            return query


# ---------------------------------------------------------------------------
# 5. Answer Generation (via Ollama)
# ---------------------------------------------------------------------------

ANSWER_PROMPT = """\
You are a helpful university assistant. Answer the question using ONLY the context below.
Include the source URL if available.
If the context doesn't contain the answer, say: "I cannot find this information."

Context:
{context}

Question: {question}

Answer:"""


class AnswerGenerator:
    def __init__(self, llm: OllamaLLM):
        self.llm = llm

    def generate(self, query: str, contexts: list[RetrievedContext]) -> str:
        blocks = []
        for i, ctx in enumerate(contexts, 1):
            block = f"[{i}] {ctx.chunk.text[:800]}"
            if ctx.chunk.source_url:
                block += f"\nSource: {ctx.chunk.source_url}"
            blocks.append(block)
        prompt = ANSWER_PROMPT.format(context="\n\n".join(blocks), question=query)
        try:
            return self.llm.chat(prompt, temperature=0.1, max_tokens=512)
        except Exception as e:
            log.error(f"[Generator] Failed: {e}")
            return "Error generating answer."


# ---------------------------------------------------------------------------
# Chunk store
# ---------------------------------------------------------------------------

class ChunkStore:
    def __init__(self, path: str):
        self.path = Path(path)
        self._data: dict[str, dict] = {}
        if self.path.exists():
            self._data = json.loads(self.path.read_text())
            log.info(f"[ChunkStore] Loaded {len(self._data)} chunks")

    def save_chunk(self, chunk: Chunk) -> None:
        self._data[chunk.chunk_id] = chunk.__dict__.copy()

    def get_chunk(self, chunk_id: str) -> Chunk | None:
        d = self._data.get(chunk_id)
        return Chunk(**d) if d else None

    def all_chunks(self) -> list[Chunk]:
        return [Chunk(**d) for d in self._data.values()]

    def flush(self) -> None:
        self.path.write_text(json.dumps(self._data, indent=2))
        log.info(f"[ChunkStore] Flushed {len(self._data)} chunks")

    def delete_chunk(self, chunk_id: str) -> None:
        self._data.pop(chunk_id, None)


# ---------------------------------------------------------------------------
# QuIM-RAG Ollama Pipeline
# ---------------------------------------------------------------------------

class QuIMRAGOllama:
    """
    Full QuIM-RAG pipeline powered entirely by Ollama (free, local).

    Usage:
        rag = QuIMRAGOllama()                          # uses llama3.2 by default
        rag = QuIMRAGOllama(OllamaConfig(generator_model="llama3.1:8b"))
        rag.ingest_document("doc1", text, source_url="https://...")
        result = rag.ask("What are the CS graduation requirements?")
        print(result["answer"])
    """

    def __init__(self, cfg: OllamaConfig | None = None):
        self.cfg = cfg or OllamaConfig()
        self.llm = OllamaLLM(self.cfg.generator_model)

        self.ingester = CorpusIngester(self.cfg)
        self.qgen = QuestionGenerator(self.cfg, self.llm)
        self.index = InvertedIndex(self.cfg)
        self.chunk_store = ChunkStore(self.cfg.chunk_store_path)
        self.rewriter = QueryRewriter(self.llm)
        self.reranker = Reranker(self.cfg)
        self.multihop = MultiHopReasoner(self.cfg, self.llm)
        self.generator = AnswerGenerator(self.llm)

        all_chunks = self.chunk_store.all_chunks()
        self.hybrid = HybridRetriever(self.cfg, self.index, all_chunks) if all_chunks else None

    def ingest_document(self, doc_id: str, text: str,
                        source_url: str = "", regenerate: bool = False) -> int:
        chunks = self.ingester.chunk_document(doc_id, text, source_url)
        new_count = 0
        for chunk in chunks:
            if self.chunk_store.get_chunk(chunk.chunk_id) and not regenerate:
                continue
            chunk.questions = self.qgen.generate(chunk)
            if not chunk.questions:
                log.warning(f"[Ingest] No questions for {chunk.chunk_id}, skipping")
                continue
            self.index.add_chunk(chunk)
            self.chunk_store.save_chunk(chunk)
            new_count += 1

        self.chunk_store.flush()
        all_chunks = self.chunk_store.all_chunks()
        if all_chunks:
            self.hybrid = HybridRetriever(self.cfg, self.index, all_chunks)
        log.info(f"[Ingest] {new_count} new chunks indexed for '{doc_id}'")
        return new_count

    def update_document(self, doc_id: str, text: str, source_url: str = "") -> int:
        for chunk in [c for c in self.chunk_store.all_chunks() if c.doc_id == doc_id]:
            self.index.delete_chunk(chunk.chunk_id)
            self.chunk_store.delete_chunk(chunk.chunk_id)
        return self.ingest_document(doc_id, text, source_url, regenerate=True)

    def _retrieve(self, query: str) -> list[dict]:
        if self.hybrid:
            return self.hybrid.retrieve(query, top_k=self.cfg.top_k * 3)
        return self.index.query(query, top_k=self.cfg.top_k * 3)

    def _hits_to_contexts(self, hits: list[dict]) -> list[RetrievedContext]:
        chunks_by_id = {c.chunk_id: c for c in self.chunk_store.all_chunks()}
        seen: set[str] = set()
        contexts = []
        for hit in hits:
            cid = hit["chunk_id"]
            if cid in seen:
                continue
            seen.add(cid)
            chunk = chunks_by_id.get(cid)
            if chunk:
                contexts.append(RetrievedContext(
                    chunk=chunk,
                    score=hit.get("rerank_score", hit.get("score", 0.0)),
                    matched_question=hit.get("question", ""),
                ))
        return contexts

    def ask(self, query: str, use_rewriter: bool = True,
            use_reranker: bool = True, use_multihop: bool = True) -> dict[str, Any]:
        # 1. Rewrite
        rewritten = self.rewriter.rewrite(query) if use_rewriter else query

        # 2. Retrieve
        hits = self._retrieve(rewritten)
        if not hits:
            return {"answer": "No indexed documents yet. Please ingest documents first.",
                    "query": query, "rewritten_query": rewritten, "contexts": [], "hops": 0}

        # 3. Re-rank
        chunks_by_id = {c.chunk_id: c for c in self.chunk_store.all_chunks()}
        if use_reranker and hits:
            hits = self.reranker.rerank(rewritten, hits, chunks_by_id, self.cfg.top_k)
        else:
            hits = hits[:self.cfg.top_k]

        contexts = self._hits_to_contexts(hits)
        combined = " ".join(c.chunk.text[:300] for c in contexts)
        hops = 0

        # 4. Multi-hop
        if use_multihop:
            for hop in range(self.cfg.max_hops):
                if not self.multihop.needs_another_hop(query, combined):
                    break
                subquery = self.multihop.generate_subquery(query, combined)
                log.info(f"[MultiHop] Hop {hop+1}: '{subquery}'")
                extra_hits = self._retrieve(subquery)
                if use_reranker and extra_hits:
                    extra_hits = self.reranker.rerank(subquery, extra_hits, chunks_by_id, top_k=2)
                extra = self._hits_to_contexts(extra_hits[:2])
                contexts.extend(extra)
                combined += " ".join(c.chunk.text[:200] for c in extra)
                hops += 1

        # Deduplicate
        seen_ids: set[str] = set()
        unique: list[RetrievedContext] = []
        for ctx in contexts:
            if ctx.chunk.chunk_id not in seen_ids:
                seen_ids.add(ctx.chunk.chunk_id)
                unique.append(ctx)

        # 5. Generate
        answer = self.generator.generate(query, unique[:self.cfg.top_k])

        return {
            "answer": answer,
            "query": query,
            "rewritten_query": rewritten,
            "hops": hops,
            "contexts": [
                {
                    "chunk_id": c.chunk.chunk_id,
                    "matched_question": c.matched_question,
                    "score": round(c.score, 4),
                    "source_url": c.chunk.source_url,
                    "snippet": c.chunk.text[:200] + "...",
                }
                for c in unique[:self.cfg.top_k]
            ],
        }

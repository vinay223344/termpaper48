"""
web_scraper.py — Corpus builder for QuIM-RAG

Crawls a seed URL and all reachable sub-pages under the same domain,
cleans the HTML, and yields plain-text documents suitable for ingestion.

Mirrors the BeautifulSoup + Scrapy approach described in the paper.
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

log = logging.getLogger(__name__)


@dataclass
class ScrapedPage:
    url: str
    doc_id: str
    text: str


class WebScraper:
    """
    Breadth-first crawler that:
      - Stays within the seed domain
      - Strips headers, footers, navbars, scripts, styles
      - Filters out pages shorter than min_chars or with 404 titles
      - Respects a polite crawl delay
    """

    # HTML tags whose content is always discarded
    NOISE_TAGS = ["header", "footer", "nav", "script", "style", "noscript", "aside"]

    # CSS classes / IDs commonly used for navigation chrome
    NOISE_CLASSES = re.compile(
        r"(nav|menu|sidebar|footer|header|breadcrumb|cookie|banner|ad[-_])",
        re.I,
    )

    def __init__(
        self,
        seed_url: str,
        max_pages: int = 500,
        min_chars: int = 250,
        crawl_delay: float = 0.5,
        timeout: int = 10,
    ):
        self.seed_url = seed_url.rstrip("/")
        self.domain = urlparse(seed_url).netloc
        self.max_pages = max_pages
        self.min_chars = min_chars
        self.crawl_delay = crawl_delay
        self.timeout = timeout

        self._visited: set[str] = set()
        self._session = requests.Session()
        self._session.headers["User-Agent"] = (
            "Mozilla/5.0 (compatible; QuIMRAGBot/1.0)"
        )

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def crawl(self) -> list[ScrapedPage]:
        """Crawl from seed URL and return all scraped pages."""
        queue = [self.seed_url]
        pages: list[ScrapedPage] = []

        while queue and len(pages) < self.max_pages:
            url = queue.pop(0)
            norm = self._normalise(url)
            if norm in self._visited:
                continue
            self._visited.add(norm)

            page = self._fetch_and_clean(url)
            if page is None:
                continue

            pages.append(page)
            log.info(f"[Scraper] Scraped {len(pages)}/{self.max_pages}: {url}")

            # Discover links
            for link in self._extract_links(url):
                if self._normalise(link) not in self._visited:
                    queue.append(link)

            time.sleep(self.crawl_delay)

        log.info(f"[Scraper] Done — {len(pages)} pages scraped")
        return pages

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _fetch_and_clean(self, url: str) -> ScrapedPage | None:
        try:
            resp = self._session.get(url, timeout=self.timeout)
            if resp.status_code != 200:
                return None
            html = resp.text
        except Exception as e:
            log.debug(f"[Scraper] Fetch error {url}: {e}")
            return None

        soup = BeautifulSoup(html, "html.parser")

        # Filter 404-style pages
        title_tag = soup.find("title")
        title_text = title_tag.get_text() if title_tag else ""
        if "404" in title_text.lower() or "not found" in title_text.lower():
            return None

        # Remove noise tags
        for tag in soup(self.NOISE_TAGS):
            tag.decompose()

        # Remove noise by class/id
        for tag in soup.find_all(True):
            classes = " ".join(tag.get("class", []))
            tag_id = tag.get("id", "")
            if self.NOISE_CLASSES.search(classes) or self.NOISE_CLASSES.search(tag_id):
                tag.decompose()

        # Extract main content
        main = soup.find("main") or soup.find("article") or soup.find("body")
        text = self._clean_text(main.get_text(separator="\n") if main else "")

        if len(text) < self.min_chars:
            return None

        doc_id = hashlib.md5(url.encode()).hexdigest()[:10]
        return ScrapedPage(url=url, doc_id=doc_id, text=text)

    def _extract_links(self, base_url: str) -> list[str]:
        try:
            resp = self._session.get(base_url, timeout=self.timeout)
            soup = BeautifulSoup(resp.text, "html.parser")
        except Exception:
            return []

        links = []
        for a in soup.find_all("a", href=True):
            href = a["href"]
            full = urljoin(base_url, href)
            parsed = urlparse(full)
            # Same domain, no fragments, no mailto/tel
            if (
                parsed.netloc == self.domain
                and parsed.scheme in ("http", "https")
                and not parsed.fragment
                and not href.startswith(("mailto:", "tel:", "javascript:"))
            ):
                links.append(full.split("#")[0])
        return list(set(links))

    @staticmethod
    def _normalise(url: str) -> str:
        return url.rstrip("/").lower().split("?")[0]

    @staticmethod
    def _clean_text(text: str) -> str:
        # Collapse whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = re.sub(r"[ \t]{2,}", " ", text)
        return text.strip()

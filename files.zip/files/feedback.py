"""
feedback.py — User Feedback Loop for QuIM-RAG (Extension)

Logs (query, retrieved_chunks, answer, feedback) tuples and uses
accepted examples to fine-tune the embedding model via contrastive loss.

Requires: pip install sentence-transformers
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class FeedbackEntry:
    query: str
    rewritten_query: str
    answer: str
    chunk_ids: list[str]
    chunk_texts: list[str]      # raw text of retrieved chunks
    rating: int                 # 1 = thumbs up, 0 = thumbs down
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class FeedbackStore:
    """Persists feedback entries to a JSONL file."""

    def __init__(self, path: str = "./feedback_log.jsonl"):
        self.path = Path(path)

    def log(self, entry: FeedbackEntry) -> None:
        with self.path.open("a") as f:
            f.write(json.dumps(entry.__dict__) + "\n")
        log.info(f"[Feedback] Logged rating={entry.rating} for query='{entry.query}'")

    def load_positive(self) -> list[FeedbackEntry]:
        """Return all thumbs-up entries."""
        entries = []
        if not self.path.exists():
            return entries
        with self.path.open() as f:
            for line in f:
                d = json.loads(line)
                if d.get("rating", 0) == 1:
                    entries.append(FeedbackEntry(**d))
        return entries

    def load_negative(self) -> list[FeedbackEntry]:
        """Return all thumbs-down entries."""
        entries = []
        if not self.path.exists():
            return entries
        with self.path.open() as f:
            for line in f:
                d = json.loads(line)
                if d.get("rating", 0) == 0:
                    entries.append(FeedbackEntry(**d))
        return entries


class EmbeddingFineTuner:
    """
    Fine-tunes the SentenceTransformer embedding model using
    MultipleNegativesRankingLoss on accepted (query, chunk) pairs.

    - Positive pairs  = (query, accepted_chunk_text)
    - In-batch negatives are used automatically by the loss function
    """

    def __init__(self, base_model_name: str, output_dir: str = "./finetuned_embedder"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(base_model_name)
        self.output_dir = output_dir

    def build_training_samples(
        self, positive_entries: list[FeedbackEntry]
    ) -> list:
        from sentence_transformers import InputExample
        samples = []
        for entry in positive_entries:
            for chunk_text in entry.chunk_texts:
                samples.append(InputExample(
                    texts=[entry.rewritten_query, chunk_text]
                ))
        log.info(f"[FineTune] Built {len(samples)} training samples")
        return samples

    def fine_tune(
        self,
        samples: list,
        epochs: int = 3,
        batch_size: int = 16,
        warmup_steps: int = 50,
    ) -> None:
        if len(samples) < 10:
            log.warning("[FineTune] Too few samples (<10), skipping fine-tuning")
            return

        from sentence_transformers import losses
        from torch.utils.data import DataLoader

        train_dl = DataLoader(samples, shuffle=True, batch_size=batch_size)
        loss_fn = losses.MultipleNegativesRankingLoss(self.model)

        self.model.fit(
            train_objectives=[(train_dl, loss_fn)],
            epochs=epochs,
            warmup_steps=warmup_steps,
            show_progress_bar=True,
            output_path=self.output_dir,
        )
        log.info(f"[FineTune] Fine-tuned model saved to {self.output_dir}")

    def run_pipeline(self, store: FeedbackStore) -> None:
        positive = store.load_positive()
        if not positive:
            log.info("[FineTune] No positive feedback yet")
            return
        samples = self.build_training_samples(positive)
        self.fine_tune(samples)

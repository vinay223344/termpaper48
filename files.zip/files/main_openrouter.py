"""
main_openrouter.py — QuIM-RAG with OpenRouter free models

Free models (pass via --model):
  nvidia/nemotron-3-super-120b-a12b:free  ← default, fast MoE (12B active params)
  nvidia/nemotron-ultra-253b-v1:free      — largest, best quality
  google/gemma-4-31b-it:free
  meta-llama/llama-4-scout:free
  deepseek/deepseek-r1:free

Get your free API key at: https://openrouter.ai (no credit card needed)

Usage:
  python main_openrouter.py --api_key sk-or-... 
  python main_openrouter.py --api_key sk-or-... --model google/gemma-4-31b-it:free
  python main_openrouter.py --api_key sk-or-... --seed_url https://catalog.ndsu.edu
  python main_openrouter.py --demo
"""

from __future__ import annotations

import argparse
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

SAMPLE_DOCS = [
    {
        "doc_id": "cs_program",
        "url": "https://catalog.ndsu.edu/undergraduate/computer-science/",
        "text": """
Computer Science (B.S.) — NDSU
Core Requirements (54 credits):
CSCI 160 Computer Science I 3 credits, CSCI 161 Computer Science II 3 credits,
CSCI 336 Computer Organization 3 credits, CSCI 366 Algorithms and Data Structures 3 credits,
CSCI 374 Operating Systems 3 credits, CSCI 474 Software Engineering 3 credits,
CSCI 489 Senior Capstone 3 credits, MATH 165 Calculus I 4 credits,
MATH 166 Calculus II 4 credits, STAT 330 Statistics 3 credits.
Graduation: 122 total credits, minimum GPA 2.0 in all CSCI courses.
Transfer students may transfer up to 64 credits, must complete 30 at NDSU.
        """,
    },
    {
        "doc_id": "career_advising",
        "url": "https://career-advising.ndsu.edu/contact/",
        "text": """
NDSU Career and Advising Center.
Location: 306 Ceres Hall, Fargo, ND 58108.
Phone: 701-231-7111. Email: ndsu.cac@ndsu.edu.
Hours: Monday to Friday 9 AM to 4 PM.
Services: resume review, mock interviews, job search via Handshake,
career fairs every fall and spring, graduate school advising.
Drop-in: Monday to Thursday 10 AM to 2 PM, no appointment needed.
Appointments: 30 minutes, book via Handshake or call 701-231-7111.
        """,
    },
]

GROUND_TRUTH_QA = [
    {
        "question": "How do I contact the NDSU Career and Advising Center?",
        "answer": "306 Ceres Hall, Fargo, ND 58108. Phone: 701-231-7111. Email: ndsu.cac@ndsu.edu.",
    },
    {
        "question": "How many credits are needed to graduate with a CS degree at NDSU?",
        "answer": "122 total credits with a minimum GPA of 2.0 in all CSCI courses.",
    },
]


def run_demo() -> None:
    print("\n" + "=" * 58)
    print("QuIM-RAG OpenRouter — Demo Mode")
    print("=" * 58)
    print("\nAvailable FREE models on OpenRouter:")
    models = [
        ("nvidia/nemotron-3-super-120b-a12b:free",  "120B  — default, fast MoE, 12B active params"),
        ("nvidia/nemotron-ultra-253b-v1:free",      "253B  — largest, best quality"),
        ("google/gemma-4-31b-it:free",              "31B   — Google, great instruction following"),
        ("meta-llama/llama-4-scout:free",           "17B   — Meta, fast"),
        ("deepseek/deepseek-r1:free",               "671B  — reasoning model"),
    ]
    for model, desc in models:
        print(f"  {model:<45} {desc}")
    print("\nTo run live:")
    print("  1. Get free API key: https://openrouter.ai")
    print("  2. python main_openrouter.py --api_key sk-or-...")
    print("  3. python main_openrouter.py --api_key sk-or-... --model google/gemma-4-31b-it:free")
    print("=" * 58)


def run_live(api_key: str, model: str, seed_url: str | None = None) -> None:
    import os
    os.makedirs("./chroma_db_openrouter", exist_ok=True)

    from quim_rag_openrouter import OpenRouterConfig, QuIMRAGOpenRouter
    from feedback import FeedbackEntry, FeedbackStore

    cfg = OpenRouterConfig(model=model)
    rag = QuIMRAGOpenRouter(api_key=api_key, cfg=cfg)

    # Ingest
    if seed_url:
        from web_scraper import WebScraper
        log.info(f"Crawling {seed_url} ...")
        pages = WebScraper(seed_url, max_pages=20).crawl()
        for page in pages:
            rag.ingest_document(page.doc_id, page.text, page.url)
    else:
        log.info("Using sample documents ...")
        for doc in SAMPLE_DOCS:
            rag.ingest_document(doc["doc_id"], doc["text"], doc["url"])

    # QA loop
    store = FeedbackStore("./feedback_log_openrouter.jsonl")
    print(f"\nQuIM-RAG (OpenRouter / {model}) ready. Type 'quit' to exit.\n")

    while True:
        query = input("Your question: ").strip()
        if query.lower() in ("quit", "exit", "q"):
            break
        if not query:
            continue

        result = rag.ask(query)

        print(f"\nAnswer:\n{result['answer']}\n")
        print(f"Model          : {result['model']}")
        print(f"Rewritten query: {result['rewritten_query']}")
        print(f"Multi-hop hops : {result['hops']}")
        print("Sources:")
        for ctx in result["contexts"]:
            if ctx["source_url"]:
                print(f"  [{ctx['score']:.3f}] {ctx['source_url']}")

        rating = input("\nRate (y=good / n=bad / s=skip): ").strip().lower()
        if rating in ("y", "n"):
            store.log(FeedbackEntry(
                query=result["query"],
                rewritten_query=result["rewritten_query"],
                answer=result["answer"],
                chunk_ids=[c["chunk_id"] for c in result["contexts"]],
                chunk_texts=[c["snippet"] for c in result["contexts"]],
                rating=1 if rating == "y" else 0,
            ))
        print()

    # Evaluation
    run_eval = input("Run BERTScore evaluation on ground truth? (y/n): ").strip().lower()
    if run_eval == "y":
        from evaluation import Evaluator, QAPair
        from sentence_transformers import SentenceTransformer

        print("\nRunning full evaluation (Faithfulness, Answer Relevance, Context Precision, Harmfulness, BERTScore)...")
        embed_model = SentenceTransformer("BAAI/bge-large-en-v1.5")
        evaluator = Evaluator(llm=rag.llm, embed_model=embed_model)

        pairs = []
        for gt in GROUND_TRUTH_QA:
            result = rag.ask(gt["question"])
            pairs.append(QAPair(
                question=gt["question"],
                ground_truth=gt["answer"],
                generated_answer=result["answer"],
                retrieved_contexts=[c["snippet"] for c in result["contexts"]],
            ))

        eval_results = evaluator.run(pairs)
        evaluator.save_results(eval_results)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="QuIM-RAG with OpenRouter free models")
    parser.add_argument("--api_key", default="", help="OpenRouter API key (sk-or-...)")
    parser.add_argument("--model", default="nvidia/nemotron-3-super-120b-a12b:free",
                        help="OpenRouter model ID")
    parser.add_argument("--seed_url", default="", help="URL to crawl")
    parser.add_argument("--demo", action="store_true", help="Show available models")
    args = parser.parse_args()

    if args.demo or not args.api_key:
        run_demo()
    else:
        run_live(args.api_key, args.model, args.seed_url or None)

"""
quim_rag_openrouter.py — QuIM-RAG pipeline using OpenRouter free models

Free models available (pass as `model` in OpenRouterConfig):
  - nvidia/nemotron-ultra-253b-v1:free   ← recommended, #1 ranked free model
  - nvidia/nemotron-3-super-120b-a12b:free
  - google/gemma-4-31b-it:free
  - meta-llama/llama-4-scout:free
  - deepseek/deepseek-r1:free

Get a free API key at: https://openrouter.ai  (no credit card needed)

OpenRouter uses the OpenAI-compatible API format, so this is a minimal
change from the original quim_rag.py — just a different base_url + model.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import chromadb
import numpy as np
from chromadb.config import Settings
from openai import OpenAI          # OpenRouter is OpenAI-compatible
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder, SentenceTransformer

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class OpenRouterConfig:
    # Free model choices — swap any time
    model: str = "nvidia/nemotron-3-super-120b-a12b:free"
    # Other free options:
    # model: str = "nvidia/nemotron-ultra-253b-v1:free"
    # model: str = "google/gemma-4-31b-it:free"
    # model: str = "meta-llama/llama-4-scout:free"
    # model: str = "deepseek/deepseek-r1:free"

    # Embedding — still local HuggingFace (free, no API needed)
    embedding_model: str = "BAAI/bge-large-en-v1.5"
    reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"

    # Chunking
    chunk_size: int = 1000
    chunk_overlap: int = 200

    # Retrieval
    top_k: int = 3
    rrf_k: int = 60
    hybrid_alpha: float = 0.5

    # Multi-hop
    max_hops: int = 2

    # Storage
    chroma_persist_dir: str = "./chroma_db_openrouter"
    collection_name: str = "quim_rag_openrouter"
    chunk_store_path: str = "./chunk_store_openrouter.json"


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    text: str
    source_url: str = ""
    questions: list[str] = field(default_factory=list)


@dataclass
class RetrievedContext:
    chunk: Chunk
    score: float
    matched_question: str


# ---------------------------------------------------------------------------
# OpenRouter LLM client
# ---------------------------------------------------------------------------

class OpenRouterLLM:
    """
    Thin wrapper around OpenAI client pointed at OpenRouter.
    Uses a custom httpx client to avoid SSL/proxy issues on Windows.
    """

    def __init__(self, api_key: str, cfg: OpenRouterConfig):
        self.cfg = cfg
        import httpx
        self.client = OpenAI(
            api_key=api_key,
            base_url=OPENROUTER_BASE_URL,
            http_client=httpx.Client(
                verify=True,
                timeout=60.0,
            ),
        )
        log.info(f"[OpenRouter] Using model: {cfg.model}")

    def chat(self, prompt: str, temperature: float = 0.1,
             max_tokens: int = 512) -> str:
        try:
            resp = self.client.chat.completions.create(
                model=self.cfg.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens,
                extra_headers={
                    "HTTP-Referer": "https://github.com/quim-rag",
                    "X-Title": "QuIM-RAG",
                },
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            log.error(f"[OpenRouter] Chat failed: {e}")
            raise


# ---------------------------------------------------------------------------
# 1. Corpus ingestion & chunking
# ---------------------------------------------------------------------------

class CorpusIngester:
    def __init__(self, cfg: OpenRouterConfig):
        self.cfg = cfg
        try:
            import tiktoken
            self._enc = tiktoken.get_encoding("cl100k_base")
        except ImportError:
            self._enc = None

    def _tokenize(self, text):
        return self._enc.encode(text) if self._enc else text.split()

    def _detokenize(self, tokens) -> str:
        return self._enc.decode(tokens) if self._enc else " ".join(tokens)

    def chunk_document(self, doc_id: str, text: str,
                       source_url: str = "") -> list[Chunk]:
        tokens = self._tokenize(text)
        chunks, step = [], self.cfg.chunk_size - self.cfg.chunk_overlap // 4
        for i, start in enumerate(range(0, len(tokens), step)):
            end = min(start + self.cfg.chunk_size, len(tokens))
            chunk_text = self._detokenize(tokens[start:end])
            if len(chunk_text.strip()) < 250:
                continue
            cid = hashlib.md5(f"{doc_id}_{i}".encode()).hexdigest()[:12]
            chunks.append(Chunk(chunk_id=cid, doc_id=doc_id,
                                text=chunk_text, source_url=source_url))
            if end >= len(tokens):
                break
        log.info(f"[Ingester] {doc_id}: {len(chunks)} chunks")
        return chunks


# ---------------------------------------------------------------------------
# 2. Question generation
# ---------------------------------------------------------------------------

QUESTION_GEN_PROMPT = """\
Your task: read the text below and output questions about it.

STRICT OUTPUT FORMAT — output ONLY a JSON array like this example:
["Question one?", "Question two?", "Question three?"]

No markdown, no code fences, no explanation, no preamble.
Start your response with [ and end with ]

Text:
{chunk_text}

JSON array of questions:"""


class QuestionGenerator:
    def __init__(self, llm: OpenRouterLLM):
        self.llm = llm

    def _extract_questions(self, raw: str) -> list[str]:
        """Try multiple strategies to extract a list of questions from LLM output."""
        # Strategy 1: find JSON array anywhere in the response
        match = re.search(r"\[.*?\]", raw, re.DOTALL)
        if match:
            try:
                questions = json.loads(match.group())
                if isinstance(questions, list) and questions:
                    return [q.strip() for q in questions if isinstance(q, str) and q.strip()]
            except json.JSONDecodeError:
                pass

        # Strategy 2: strip markdown fences then parse
        cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        if cleaned.startswith("["):
            try:
                questions = json.loads(cleaned)
                if isinstance(questions, list) and questions:
                    return [q.strip() for q in questions if isinstance(q, str) and q.strip()]
            except json.JSONDecodeError:
                pass

        # Strategy 3: extract quoted strings that look like questions
        quoted = re.findall(r'"([^"]{10,}[?])"', raw)
        if quoted:
            return [q.strip() for q in quoted]

        # Strategy 4: extract numbered/bulleted lines as questions
        lines = [
            re.sub(r"^[\d\-\*\.\)]+\s*", "", line).strip()
            for line in raw.splitlines()
            if line.strip() and "?" in line
        ]
        if lines:
            return lines

        return []

    def generate(self, chunk: Chunk, max_questions: int = 8) -> list[str]:
        prompt = QUESTION_GEN_PROMPT.format(chunk_text=chunk.text[:2500])
        try:
            raw = self.llm.chat(prompt, temperature=0.2, max_tokens=700)
            log.debug(f"[QGen] Raw response for {chunk.chunk_id}: {raw[:200]}")
            questions = self._extract_questions(raw)
            if not questions:
                log.warning(f"[QGen] No questions extracted for chunk {chunk.chunk_id}. Raw: {raw[:300]}")
                return []
            # Filter out placeholder/generic questions
            PLACEHOLDERS = {'question one', 'question two', 'question three',
                            'question 1', 'question 2', 'question 3', 'question four',
                            'question five', 'question six', 'question seven'}
            questions = [q for q in questions
                         if q.lower().strip().rstrip('?') not in PLACEHOLDERS
                         and len(q.strip()) > 10]
            if not questions:
                log.warning(f"[QGen] Only placeholder questions for {chunk.chunk_id}, skipping")
                return []
            return questions[:max_questions]
        except Exception as e:
            log.warning(f"[QGen] Failed for chunk {chunk.chunk_id}: {e}")
            return []


# ---------------------------------------------------------------------------
# 3. Inverted index (ChromaDB)
# ---------------------------------------------------------------------------

class PrototypeQuantizer:
    """
    Implements the quantization step from the paper:
      pl = arg min_p CosineSimilarity(v_ijl, p)

    Learns k prototype vectors via K-Means clustering over all
    question embeddings. Each new embedding is then snapped to
    its nearest prototype before being stored in the inverted index.

    This reduces retrieval complexity from O(N) to O(k + bucket_size).
    """

    def __init__(self, n_prototypes: int = 64):
        self.n_prototypes = n_prototypes
        self.prototypes: np.ndarray | None = None  # shape (k, d)
        self._fitted = False

    def fit(self, embeddings: np.ndarray) -> None:
        """Fit prototypes using K-Means on all question embeddings."""
        import numpy as np
        from sklearn.cluster import MiniBatchKMeans

        n = len(embeddings)
        k = min(self.n_prototypes, n)  # can't have more clusters than points
        if k < 2:
            # Too few embeddings — use them directly as prototypes
            self.prototypes = embeddings.copy()
            self._fitted = True
            log.info(f"[Quantizer] {k} prototypes (trivial — too few embeddings)")
            return

        kmeans = MiniBatchKMeans(n_clusters=k, random_state=42, n_init=3)
        kmeans.fit(embeddings)
        # Normalize prototype vectors (cosine similarity requires unit vectors)
        centers = kmeans.cluster_centers_
        norms = np.linalg.norm(centers, axis=1, keepdims=True)
        self.prototypes = centers / np.maximum(norms, 1e-9)
        self._fitted = True
        log.info(f"[Quantizer] Fitted {k} prototypes over {n} embeddings")

    def quantize(self, embedding: np.ndarray) -> int:
        """Return index of nearest prototype (by cosine similarity)."""
        import numpy as np
        if not self._fitted or self.prototypes is None:
            return 0
        # cosine similarity = dot product (both are unit vectors)
        sims = self.prototypes @ embedding
        return int(np.argmax(sims))

    def quantize_batch(self, embeddings: np.ndarray) -> list[int]:
        import numpy as np
        if not self._fitted or self.prototypes is None:
            return [0] * len(embeddings)
        sims = embeddings @ self.prototypes.T   # (n, k)
        return np.argmax(sims, axis=1).tolist()


class InvertedIndex:
    """
    Full paper implementation:
      1. Embed questions with BAAI/bge-large-en-v1.5
      2. Fit prototype vectors via K-Means (PrototypeQuantizer)
      3. Quantize each embedding → nearest prototype index
      4. Build inverted index: prototype_id → [(vec_id, chunk_id)]
      5. At query time: quantize query → look up prototype bucket → rank by cosine sim
      6. ChromaDB stores all vectors for final similarity scoring within bucket
    """

    def __init__(self, cfg: OpenRouterConfig):
        import numpy as np
        self.cfg = cfg
        self.embed_model = SentenceTransformer(cfg.embedding_model)
        self.quantizer = PrototypeQuantizer(n_prototypes=64)

        # inverted_index[prototype_id] = list of vec_ids in that bucket
        self._inverted_index: dict[int, list[str]] = {}
        # all embeddings accumulated before fitting prototypes
        self._pending_embeddings: list[np.ndarray] = []
        self._pending_meta: list[dict] = []   # {vec_id, chunk_id, doc_id, source_url, question}

        chroma_client = chromadb.PersistentClient(
            path=cfg.chroma_persist_dir,
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = chroma_client.get_or_create_collection(
            name=cfg.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        log.info(f"[Index] Ready ({self.collection.count()} vectors)")

    def add_chunk(self, chunk: Chunk) -> None:
        """Embed questions, accumulate for prototype fitting, upsert to ChromaDB."""
        import numpy as np
        if not chunk.questions:
            return

        embeddings = self.embed_model.encode(
            chunk.questions, normalize_embeddings=True
        )  # shape (n_questions, d)

        ids, docs, metas, embs = [], [], [], []
        for q_idx, (q, emb) in enumerate(zip(chunk.questions, embeddings)):
            vec_id = f"{chunk.chunk_id}_q{q_idx}"
            ids.append(vec_id)
            docs.append(q)
            metas.append({"chunk_id": chunk.chunk_id, "doc_id": chunk.doc_id,
                          "source_url": chunk.source_url})
            embs.append(emb.tolist())

            # Accumulate for prototype fitting
            self._pending_embeddings.append(emb)
            self._pending_meta.append({
                "vec_id": vec_id, "chunk_id": chunk.chunk_id,
                "doc_id": chunk.doc_id, "source_url": chunk.source_url,
                "question": q,
            })

        self.collection.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=embs)

    def build_prototype_index(self) -> None:
        """
        Call after all chunks are ingested.
        Fits prototypes and builds the inverted index mapping
        prototype_id → [vec_ids].
        """
        import numpy as np
        if not self._pending_embeddings:
            log.warning("[Index] No embeddings to build prototype index from")
            return

        all_embs = np.stack(self._pending_embeddings)   # (N, d)
        self.quantizer.fit(all_embs)

        # Assign each embedding to its nearest prototype
        prototype_ids = self.quantizer.quantize_batch(all_embs)
        self._inverted_index = {}
        for proto_id, meta in zip(prototype_ids, self._pending_meta):
            self._inverted_index.setdefault(proto_id, []).append(meta["vec_id"])

        total_buckets = len(self._inverted_index)
        avg_bucket = len(self._pending_embeddings) / max(total_buckets, 1)
        log.info(f"[Index] Prototype index built: {total_buckets} buckets, "
                 f"avg {avg_bucket:.1f} vectors/bucket")

    def query(self, query_text: str, top_k: int = 10) -> list[dict]:
        """
        Paper Algorithm:
          1. Embed query
          2. Quantize to nearest prototype
          3. Retrieve all vec_ids in that prototype's bucket
          4. Score by cosine similarity, return top_k
        """
        import numpy as np
        count = self.collection.count()
        if count == 0:
            return []

        q_emb = self.embed_model.encode(
            [query_text], normalize_embeddings=True
        )[0]  # shape (d,)

        # Step 2: quantize query to nearest prototype
        if self.quantizer._fitted and self._inverted_index:
            proto_id = self.quantizer.quantize(q_emb)
            bucket_ids = self._inverted_index.get(proto_id, [])

            # Also check adjacent prototypes for robustness (top-3 prototypes)
            sims = self.quantizer.prototypes @ q_emb
            top_protos = np.argsort(sims)[::-1][:3]
            for p in top_protos:
                bucket_ids = list(set(bucket_ids + self._inverted_index.get(int(p), [])))

            log.debug(f"[Index] Prototype {proto_id} → {len(bucket_ids)} candidates")

            if bucket_ids:
                # Fetch only vectors in this prototype's bucket from ChromaDB
                bucket_results = self.collection.get(
                    ids=bucket_ids[:200],  # cap for performance
                    include=["documents", "metadatas", "embeddings"],
                )
                if bucket_results["ids"]:
                    # Score by cosine similarity within bucket
                    hits = []
                    for vec_id, doc, meta, emb in zip(
                        bucket_results["ids"],
                        bucket_results["documents"],
                        bucket_results["metadatas"],
                        bucket_results["embeddings"],
                    ):
                        sim = float(np.dot(q_emb, np.array(emb)))
                        hits.append({
                            "question": doc,
                            "chunk_id": meta["chunk_id"],
                            "doc_id": meta.get("doc_id", ""),
                            "source_url": meta.get("source_url", ""),
                            "score": sim,
                        })
                    hits.sort(key=lambda h: h["score"], reverse=True)
                    return hits[:top_k]

        # Fallback: full ChromaDB ANN search (when prototype index not yet built)
        log.debug("[Index] Falling back to full ANN search")
        q_emb_list = q_emb.tolist()
        results = self.collection.query(
            query_embeddings=[q_emb_list],
            n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"],
        )
        hits = []
        if results["ids"] and results["ids"][0]:
            for doc, meta, dist in zip(results["documents"][0],
                                       results["metadatas"][0],
                                       results["distances"][0]):
                hits.append({"question": doc, "chunk_id": meta["chunk_id"],
                             "doc_id": meta.get("doc_id", ""),
                             "source_url": meta.get("source_url", ""),
                             "score": 1.0 - dist})
        return hits

    def delete_chunk(self, chunk_id: str) -> None:
        results = self.collection.get(where={"chunk_id": chunk_id})
        if results["ids"]:
            self.collection.delete(ids=results["ids"])
            # Remove from inverted index
            for bucket in self._inverted_index.values():
                for vid in results["ids"]:
                    if vid in bucket:
                        bucket.remove(vid)


# ---------------------------------------------------------------------------
# 4a. Query Rewriting
# ---------------------------------------------------------------------------

REWRITE_PROMPT = """\
Rewrite this question to be more specific and self-contained for searching
a university knowledge base. Return ONLY the rewritten question, nothing else.

Question: {query}
Rewritten:"""


class QueryRewriter:
    def __init__(self, llm: OpenRouterLLM):
        self.llm = llm

    def rewrite(self, query: str) -> str:
        if len(query.split()) > 10:
            return query
        try:
            rewritten = self.llm.chat(
                REWRITE_PROMPT.format(query=query), temperature=0.0, max_tokens=80
            ).split("\n")[0].strip()
            log.info(f"[Rewriter] '{query}' → '{rewritten}'")
            return rewritten
        except Exception:
            return query


# ---------------------------------------------------------------------------
# 4b. Hybrid Retrieval (BM25 + Dense + RRF)
# ---------------------------------------------------------------------------

class HybridRetriever:
    def __init__(self, cfg: OpenRouterConfig, index: InvertedIndex,
                 chunks: list[Chunk]):
        self.cfg = cfg
        self.index = index
        self.chunks_by_id = {c.chunk_id: c for c in chunks}
        self.chunk_order = [c.chunk_id for c in chunks]
        if chunks:
            self.bm25 = BM25Okapi([c.text.lower().split() for c in chunks])
            log.info(f"[BM25] Built over {len(chunks)} chunks")
        else:
            self.bm25 = None
            log.warning("[BM25] No chunks — skipped")

    def retrieve(self, query: str, top_k: int) -> list[dict]:
        dense_hits = self.index.query(query, top_k=top_k * 3)
        dense_scores: dict[str, float] = {}
        for rank, hit in enumerate(dense_hits):
            cid = hit["chunk_id"]
            if cid not in dense_scores:
                dense_scores[cid] = 1.0 / (self.cfg.rrf_k + rank + 1)

        sparse_scores: dict[str, float] = {}
        if self.bm25 and self.chunk_order:
            raw = self.bm25.get_scores(query.lower().split())
            ranked = sorted(enumerate(raw), key=lambda x: x[1], reverse=True)[:top_k * 3]
            for rank, (idx, _) in enumerate(ranked):
                sparse_scores[self.chunk_order[idx]] = 1.0 / (self.cfg.rrf_k + rank + 1)

        all_ids = set(dense_scores) | set(sparse_scores)
        fused = sorted(
            [(cid, self.cfg.hybrid_alpha * dense_scores.get(cid, 0)
              + (1 - self.cfg.hybrid_alpha) * sparse_scores.get(cid, 0))
             for cid in all_ids],
            key=lambda x: x[1], reverse=True,
        )
        results = []
        for cid, score in fused[:top_k]:
            chunk = self.chunks_by_id.get(cid)
            if not chunk:
                continue
            matched_q = next((h["question"] for h in dense_hits if h["chunk_id"] == cid),
                             chunk.questions[0] if chunk.questions else "")
            results.append({"chunk_id": cid, "question": matched_q,
                            "score": score, "source_url": chunk.source_url})
        return results


# ---------------------------------------------------------------------------
# 4c. Cross-Encoder Re-Ranking
# ---------------------------------------------------------------------------

class Reranker:
    def __init__(self, cfg: OpenRouterConfig):
        self.model = CrossEncoder(cfg.reranker_model)
        log.info(f"[Reranker] Loaded {cfg.reranker_model}")

    def rerank(self, query: str, hits: list[dict],
               chunks_by_id: dict[str, Chunk], top_k: int) -> list[dict]:
        pairs = [(query, chunks_by_id[h["chunk_id"]].text[:512]
                  if h["chunk_id"] in chunks_by_id else h["question"])
                 for h in hits]
        scores = self.model.predict(pairs).tolist()
        for hit, score in zip(hits, scores):
            hit["rerank_score"] = score
        return sorted(hits, key=lambda h: h["rerank_score"], reverse=True)[:top_k]


# ---------------------------------------------------------------------------
# 4d. Multi-hop Reasoning
# ---------------------------------------------------------------------------

SUBQUERY_PROMPT = """\
The context below is insufficient to fully answer the question.
Identify ONE specific sub-question that would help complete the answer.
Return ONLY the sub-question, nothing else.

Question: {query}
Partial context: {partial_context}
Sub-question:"""


class MultiHopReasoner:
    def __init__(self, cfg: OpenRouterConfig, llm: OpenRouterLLM):
        self.cfg = cfg
        self.llm = llm

    def needs_another_hop(self, query: str, context: str) -> bool:
        overlap = len(set(query.lower().split()) & set(context.lower().split()))
        return overlap < 3 and len(context) < 400

    def generate_subquery(self, query: str, partial_context: str) -> str:
        try:
            return self.llm.chat(
                SUBQUERY_PROMPT.format(query=query,
                                       partial_context=partial_context[:600]),
                temperature=0.2, max_tokens=80,
            )
        except Exception:
            return query


# ---------------------------------------------------------------------------
# 5. Answer Generation
# ---------------------------------------------------------------------------

ANSWER_PROMPT = """\
You are a helpful university assistant. Answer the question using ONLY the context below.
Include the source URL when available.
If the context does not contain the answer, say: "I cannot find this information."
Keep your answer concise and do not repeat yourself.

Context:
{context}

Question: {question}

Answer (be concise, do not repeat):"""


class AnswerGenerator:
    def __init__(self, llm: OpenRouterLLM):
        self.llm = llm

    def generate(self, query: str, contexts: list[RetrievedContext]) -> str:
        blocks = []
        for i, ctx in enumerate(contexts, 1):
            block = f"[{i}] {ctx.chunk.text[:800]}"
            if ctx.chunk.source_url:
                block += f"\nSource: {ctx.chunk.source_url}"
            blocks.append(block)
        if not blocks:
            return "No relevant context found."
        prompt = ANSWER_PROMPT.format(
            context="\n\n".join(blocks), question=query
        )
        try:
            return self.llm.chat(prompt, temperature=0.1, max_tokens=300)
        except Exception as e:
            log.error(f"[Generator] Failed: {e}")
            return "Error generating answer."


# ---------------------------------------------------------------------------
# Chunk store
# ---------------------------------------------------------------------------

class ChunkStore:
    def __init__(self, path: str):
        self.path = Path(path)
        self._data: dict[str, dict] = {}
        if self.path.exists():
            self._data = json.loads(self.path.read_text())
            log.info(f"[ChunkStore] Loaded {len(self._data)} chunks")

    def save_chunk(self, chunk: Chunk) -> None:
        self._data[chunk.chunk_id] = chunk.__dict__.copy()

    def get_chunk(self, chunk_id: str) -> Chunk | None:
        d = self._data.get(chunk_id)
        return Chunk(**d) if d else None

    def all_chunks(self) -> list[Chunk]:
        return [Chunk(**d) for d in self._data.values()]

    def flush(self) -> None:
        self.path.write_text(json.dumps(self._data, indent=2))
        log.info(f"[ChunkStore] Flushed {len(self._data)} chunks")

    def delete_chunk(self, chunk_id: str) -> None:
        self._data.pop(chunk_id, None)


# ---------------------------------------------------------------------------
# QuIM-RAG OpenRouter Pipeline
# ---------------------------------------------------------------------------

class QuIMRAGOpenRouter:
    """
    Full QuIM-RAG pipeline using OpenRouter free models.

    Usage:
        rag = QuIMRAGOpenRouter(api_key="sk-or-...")
        # or use a specific model:
        cfg = OpenRouterConfig(model="google/gemma-4-31b-it:free")
        rag = QuIMRAGOpenRouter(api_key="sk-or-...", cfg=cfg)

        rag.ingest_document("doc1", text, source_url="https://...")
        result = rag.ask("What are the CS graduation requirements?")
        print(result["answer"])
    """

    def __init__(self, api_key: str, cfg: OpenRouterConfig | None = None):
        self.cfg = cfg or OpenRouterConfig()
        self.llm = OpenRouterLLM(api_key, self.cfg)

        self.ingester = CorpusIngester(self.cfg)
        self.qgen = QuestionGenerator(self.llm)
        self.index = InvertedIndex(self.cfg)
        self.chunk_store = ChunkStore(self.cfg.chunk_store_path)
        self.rewriter = QueryRewriter(self.llm)
        self.reranker = Reranker(self.cfg)
        self.multihop = MultiHopReasoner(self.cfg, self.llm)
        self.generator = AnswerGenerator(self.llm)

        all_chunks = self.chunk_store.all_chunks()
        self.hybrid = HybridRetriever(self.cfg, self.index, all_chunks) if all_chunks else None

    def ingest_document(self, doc_id: str, text: str,
                        source_url: str = "", regenerate: bool = False) -> int:
        chunks = self.ingester.chunk_document(doc_id, text, source_url)
        new_count = 0
        for chunk in chunks:
            if self.chunk_store.get_chunk(chunk.chunk_id) and not regenerate:
                continue
            chunk.questions = self.qgen.generate(chunk)
            if not chunk.questions:
                log.warning(f"[Ingest] No questions for {chunk.chunk_id}, skipping")
                continue
            self.index.add_chunk(chunk)
            self.chunk_store.save_chunk(chunk)
            new_count += 1
        self.chunk_store.flush()
        all_chunks = self.chunk_store.all_chunks()
        if all_chunks:
            self.hybrid = HybridRetriever(self.cfg, self.index, all_chunks)
            # Build prototype index after ingestion (paper Section III-B.4)
            self.index.build_prototype_index()
        log.info(f"[Ingest] {new_count} new chunks indexed for '{doc_id}'")
        return new_count

    def update_document(self, doc_id: str, text: str, source_url: str = "") -> int:
        for chunk in [c for c in self.chunk_store.all_chunks() if c.doc_id == doc_id]:
            self.index.delete_chunk(chunk.chunk_id)
            self.chunk_store.delete_chunk(chunk.chunk_id)
        return self.ingest_document(doc_id, text, source_url, regenerate=True)

    def _retrieve(self, query: str) -> list[dict]:
        if self.hybrid:
            return self.hybrid.retrieve(query, top_k=self.cfg.top_k * 3)
        return self.index.query(query, top_k=self.cfg.top_k * 3)

    def _hits_to_contexts(self, hits: list[dict]) -> list[RetrievedContext]:
        chunks_by_id = {c.chunk_id: c for c in self.chunk_store.all_chunks()}
        seen: set[str] = set()
        contexts = []
        for hit in hits:
            cid = hit["chunk_id"]
            if cid in seen:
                continue
            seen.add(cid)
            chunk = chunks_by_id.get(cid)
            if chunk:
                contexts.append(RetrievedContext(
                    chunk=chunk,
                    score=hit.get("rerank_score", hit.get("score", 0.0)),
                    matched_question=hit.get("question", ""),
                ))
        return contexts

    def ask(self, query: str, use_rewriter: bool = True,
            use_reranker: bool = True, use_multihop: bool = True) -> dict[str, Any]:
        # 1. Rewrite
        rewritten = self.rewriter.rewrite(query) if use_rewriter else query

        # 2. Retrieve
        hits = self._retrieve(rewritten)
        if not hits:
            return {"answer": "No indexed documents yet. Please ingest documents first.",
                    "query": query, "rewritten_query": rewritten,
                    "contexts": [], "hops": 0}

        # 3. Re-rank
        chunks_by_id = {c.chunk_id: c for c in self.chunk_store.all_chunks()}
        if use_reranker and hits:
            hits = self.reranker.rerank(rewritten, hits, chunks_by_id, self.cfg.top_k)
        else:
            hits = hits[:self.cfg.top_k]

        contexts = self._hits_to_contexts(hits)
        combined = " ".join(c.chunk.text[:300] for c in contexts)
        hops = 0

        # 4. Multi-hop
        if use_multihop:
            for hop in range(self.cfg.max_hops):
                if not self.multihop.needs_another_hop(query, combined):
                    break
                subquery = self.multihop.generate_subquery(query, combined)
                log.info(f"[MultiHop] Hop {hop+1}: '{subquery}'")
                extra_hits = self._retrieve(subquery)
                if use_reranker and extra_hits:
                    extra_hits = self.reranker.rerank(subquery, extra_hits, chunks_by_id, top_k=2)
                extra = self._hits_to_contexts(extra_hits[:2])
                contexts.extend(extra)
                combined += " ".join(c.chunk.text[:200] for c in extra)
                hops += 1

        # Deduplicate
        seen_ids: set[str] = set()
        unique: list[RetrievedContext] = []
        for ctx in contexts:
            if ctx.chunk.chunk_id not in seen_ids:
                seen_ids.add(ctx.chunk.chunk_id)
                unique.append(ctx)

        # 5. Generate
        answer = self.generator.generate(query, unique[:self.cfg.top_k])

        return {
            "answer": answer,
            "query": query,
            "rewritten_query": rewritten,
            "hops": hops,
            "model": self.cfg.model,
            "contexts": [
                {"chunk_id": c.chunk.chunk_id,
                 "matched_question": c.matched_question,
                 "score": round(c.score, 4),
                 "source_url": c.chunk.source_url,
                 "snippet": c.chunk.text[:200] + "..."}
                for c in unique[:self.cfg.top_k]
            ],
        }

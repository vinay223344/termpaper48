"""
main.py — End-to-end demo of QuIM-RAG

Demonstrates:
  1. Scraping a university website
  2. Ingesting corpus into QuIM-RAG
  3. Asking questions (with all extensions active)
  4. Logging feedback
  5. Running evaluation on ground-truth QA pairs

Run:
    python main.py --api_key sk-...
    python main.py --demo           # uses sample in-memory text, no API calls
"""

from __future__ import annotations

import argparse
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ── Sample corpus (used in --demo mode) ────────────────────────────────────

SAMPLE_DOCS = [
    {
        "doc_id": "cs_program",
        "url": "https://catalog.ndsu.edu/undergraduate/computer-science/",
        "text": """
Computer Science (B.S.) — NDSU

The Bachelor of Science in Computer Science at North Dakota State University
prepares students for careers in software development, data science, artificial
intelligence, and systems programming.

Admission Requirements:
Students must complete MATH 165 (Calculus I) and CSCI 160 (Computer Science I)
with a grade of C or better before declaring Computer Science as their major.

Core Requirements (54 credits):
- CSCI 160: Computer Science I (3 credits)
- CSCI 161: Computer Science II (3 credits)
- CSCI 213: Object-Oriented Programming (3 credits)
- CSCI 336: Computer Organization (3 credits)
- CSCI 366: Algorithms and Data Structures (3 credits)
- CSCI 374: Operating Systems (3 credits)
- CSCI 436: Programming Languages (3 credits)
- CSCI 474: Software Engineering (3 credits)
- CSCI 489: Senior Capstone (3 credits)
- MATH 165, 166: Calculus I & II (8 credits)
- MATH 270: Introduction to Abstract Mathematics (3 credits)
- MATH 329: Linear Algebra (3 credits)
- STAT 330: Statistics (3 credits)

Graduation Requirements:
Students must complete 122 total credits with a minimum GPA of 2.0 in all
CSCI courses. A senior capstone project is required. Students must also
fulfill the NDSU University Studies requirements (General Education).

Transfer Students:
Transfer students with an associate degree from an accredited institution
may transfer up to 64 credits. All transfer CSCI credits are subject to
departmental approval. Transfer students must complete at least 30 credits
at NDSU before graduating.
        """,
    },
    {
        "doc_id": "career_advising",
        "url": "https://career-advising.ndsu.edu/contact/",
        "text": """
NDSU Career and Advising Center — Contact Information

Location: 306 Ceres Hall, Fargo, ND 58108
Phone: 701-231-7111
Email: ndsu.cac@ndsu.edu
Hours: Monday–Friday, 9 AM–4 PM

Services Offered:
The Career and Advising Center provides a full range of career development
services to NDSU students and alumni:

- Resume and cover letter review (drop-in or by appointment)
- Mock interview preparation (in-person or video)
- Job and internship search assistance via Handshake platform
- Career fairs (fall and spring semesters)
- Graduate school advising
- LinkedIn profile workshops

Handshake Platform:
All students are automatically registered on Handshake using their NDSU
email. Students can search for internships, full-time jobs, and on-campus
employment. Over 3,000 employers actively recruit NDSU students on Handshake.

Drop-In Hours:
Students may drop in without an appointment Monday–Thursday 10 AM–2 PM
for 15-minute express advising sessions on resumes, cover letters, and
quick career questions.

Appointments:
Full 30-minute appointments can be booked online via Handshake or by
calling 701-231-7111.
        """,
    },
    {
        "doc_id": "financial_aid",
        "url": "https://catalog.ndsu.edu/undergraduate/financial-aid/",
        "text": """
Financial Aid at NDSU

NDSU offers a comprehensive financial aid program including scholarships,
grants, loans, and work-study opportunities.

Priority Deadline: February 1 for the following academic year.
Application: Students must submit the FAFSA (Free Application for Federal
Student Aid) at studentaid.gov using NDSU's school code: 002997.

Types of Aid:

1. Scholarships
   - Presidential Scholarship: Full tuition, renewable for 4 years,
     requires 3.9+ high school GPA and 30+ ACT.
   - Merit Scholarship: Up to $5,000/year, requires 3.5+ GPA and 26+ ACT.
   - Departmental Scholarships: Varies by college. Contact your academic
     department for details.

2. Grants
   - Federal Pell Grant: Up to $7,395/year for eligible students.
   - North Dakota Need-Based Grant: Up to $2,000/year for ND residents.

3. Loans
   - Federal Direct Subsidized Loan: Up to $5,500/year for freshmen.
   - Federal Direct Unsubsidized Loan: Up to $7,500/year.
   - Parent PLUS Loan: Available for parents of dependent students.

4. Work-Study
   - Federal Work-Study provides part-time employment (typically 10–15
     hours/week) at $12–$15/hour for eligible students.

Contact:
Office of Financial Aid, 106 Putnam Hall
Phone: 701-231-6200 | Email: ndsu.finaid@ndsu.edu
        """,
    },
]

# ── Ground-truth QA pairs for evaluation ───────────────────────────────────

GROUND_TRUTH_QA = [
    {
        "question": "What are the core course requirements for a CS degree at NDSU?",
        "answer": "The CS B.S. requires 54 credits of core courses including CSCI 160-161, "
                  "CSCI 213, 336, 366, 374, 436, 474, 489, calculus I & II, linear algebra, "
                  "abstract math, and statistics.",
    },
    {
        "question": "How do I contact the NDSU Career and Advising Center?",
        "answer": "The Career and Advising Center is at 306 Ceres Hall, Fargo, ND 58108. "
                  "Phone: 701-231-7111. Email: ndsu.cac@ndsu.edu. Hours: Mon-Fri 9 AM-4 PM.",
    },
    {
        "question": "What is the FAFSA school code for NDSU?",
        "answer": "NDSU's FAFSA school code is 002997.",
    },
    {
        "question": "How many credits can transfer students bring to NDSU?",
        "answer": "Transfer students with an associate degree may transfer up to 64 credits. "
                  "At least 30 credits must be completed at NDSU before graduating.",
    },
]


# ── Main ────────────────────────────────────────────────────────────────────

def run_demo() -> None:
    """Demo mode: shows the QuIM-RAG workflow without real API calls."""
    print("\n" + "=" * 60)
    print("QuIM-RAG Demo (mock mode — no real API calls)")
    print("=" * 60)

    print("\n[Step 1] Corpus ingestion")
    print(f"  {len(SAMPLE_DOCS)} documents available")
    for doc in SAMPLE_DOCS:
        print(f"  • {doc['doc_id']} ({len(doc['text'])} chars) — {doc['url']}")

    print("\n[Step 2] Question generation (sample)")
    sample_questions = [
        "What are the core requirements for the Computer Science B.S.?",
        "What GPA do CS students need in their major courses?",
        "How many total credits are required to graduate with a CS degree?",
        "What is the senior capstone requirement for CS students?",
    ]
    print(f"  Generated {len(sample_questions)} questions for 'cs_program' chunk:")
    for q in sample_questions:
        print(f"    - {q}")

    print("\n[Step 3] Embedding + inverted index")
    print("  Vectors stored in ChromaDB (BAAI/bge-large-en-v1.5)")
    print("  BM25 index built over raw chunk text")

    print("\n[Step 4] Query pipeline demonstration")
    test_queries = [
        "CS requirements NDSU",   # short → triggers rewriter
        "contact career center",  # short → triggers rewriter
    ]
    rewrites = [
        "What are the Computer Science degree requirements at NDSU?",
        "How do I contact the NDSU Career and Advising Center?",
    ]
    for q, r in zip(test_queries, rewrites):
        print(f"  Original : '{q}'")
        print(f"  Rewritten: '{r}'")
        print()

    print("[Step 5] Hybrid retrieval + re-ranking")
    print("  Dense (cosine): top-9 candidates")
    print("  BM25 sparse:    top-9 candidates")
    print("  RRF fusion:     combined ranking")
    print("  Cross-encoder:  re-scored, top-3 kept")

    print("\n[Step 6] Sample answer (mock)")
    print("  Q: contact career center")
    print("  A: The NDSU Career and Advising Center is located at")
    print("     306 Ceres Hall, Fargo, ND 58108.")
    print("     Phone: 701-231-7111 | Email: ndsu.cac@ndsu.edu")
    print("     Source: https://career-advising.ndsu.edu/contact/")

    print("\n[Step 7] Feedback logging (mock)")
    print("  User rated answer: thumbs_up=True")
    print("  Entry logged to feedback_log.jsonl")

    print("\n[Step 8] Evaluation metrics (expected from paper)")
    metrics = {
        "faithfulness":        1.00,
        "answer_relevancy":    0.99,
        "context_precision":   0.92,
        "context_recall":      0.74,
        "bert_precision":      0.63,
        "bert_recall":         0.71,
        "bert_f1":             0.67,
    }
    print(f"  {'Metric':<28} {'Score':>6}")
    print("  " + "-" * 36)
    for metric, value in metrics.items():
        print(f"  {metric:<28} {value:.2f}")

    print("\n" + "=" * 60)
    print("Demo complete. Run with --api_key sk-... for live mode.")
    print("=" * 60 + "\n")


def run_live(api_key: str, seed_url: str | None = None) -> None:
    """Live mode: real API calls, real ChromaDB, real evaluation."""
    import os
    os.makedirs("./chroma_db", exist_ok=True)

    from quim_rag import QuIMConfig, QuIMRAG
    from evaluation import Evaluator, QAPair
    from feedback import FeedbackEntry, FeedbackStore

    cfg = QuIMConfig()
    rag = QuIMRAG(cfg, openai_api_key=api_key)

    # ── 1. Ingest corpus ──────────────────────────────────────────────────
    if seed_url:
        from web_scraper import WebScraper
        log.info(f"Crawling {seed_url} …")
        scraper = WebScraper(seed_url, max_pages=20)
        pages = scraper.crawl()
        for page in pages:
            rag.ingest_document(page.doc_id, page.text, page.url)
    else:
        log.info("No seed URL provided — using sample documents")
        for doc in SAMPLE_DOCS:
            rag.ingest_document(doc["doc_id"], doc["text"], doc["url"])

    # ── 2. Interactive QA loop ────────────────────────────────────────────
    store = FeedbackStore()
    print("\nQuIM-RAG is ready. Type 'quit' to exit.\n")

    while True:
        query = input("Your question: ").strip()
        if query.lower() in ("quit", "exit", "q"):
            break
        if not query:
            continue

        result = rag.ask(query)

        print(f"\nAnswer:\n{result['answer']}\n")
        print(f"Rewritten query : {result['rewritten_query']}")
        print(f"Multi-hop rounds: {result['hops']}")
        print("Retrieved chunks:")
        for ctx in result["contexts"]:
            print(f"  [{ctx['score']:.3f}] {ctx['snippet'][:80]}...")
            if ctx["source_url"]:
                print(f"           Source: {ctx['source_url']}")

        rating_input = input("\nRate this answer (y=good / n=bad / s=skip): ").strip().lower()
        if rating_input in ("y", "n"):
            entry = FeedbackEntry(
                query=result["query"],
                rewritten_query=result["rewritten_query"],
                answer=result["answer"],
                chunk_ids=[c["chunk_id"] for c in result["contexts"]],
                chunk_texts=[c["snippet"] for c in result["contexts"]],
                rating=1 if rating_input == "y" else 0,
            )
            store.log(entry)
        print()

    # ── 3. Evaluation ─────────────────────────────────────────────────────
    print("\nRunning evaluation on ground-truth QA pairs …")
    evaluator = Evaluator(api_key)
    pairs = []
    for gt in GROUND_TRUTH_QA:
        result = rag.ask(gt["question"])
        pairs.append(QAPair(
            question=gt["question"],
            ground_truth=gt["answer"],
            generated_answer=result["answer"],
            retrieved_contexts=[c["snippet"] for c in result["contexts"]],
        ))
    eval_results = evaluator.run(pairs)
    evaluator.save_results(eval_results)


# ── Entry point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="QuIM-RAG demo")
    parser.add_argument("--api_key", type=str, default="", help="OpenAI API key")
    parser.add_argument("--seed_url", type=str, default="", help="URL to crawl")
    parser.add_argument("--demo", action="store_true", help="Run mock demo (no API)")
    args = parser.parse_args()

    if args.demo or not args.api_key:
        run_demo()
    else:
        run_live(args.api_key, args.seed_url or None)

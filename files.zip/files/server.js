const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const cors = require('cors');

const app = express();

// Increase payload size limit to handle larger data (e.g., base64 images)
app.use(express.json({ limit: '10mb' }));
app.use(cors());

// MongoDB Connection
const connectToMongoDB = async () => {
    try {
        await mongoose.connect('mongodb://localhost:27017/learnpath', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('Connected to MongoDB successfully');
    } catch (err) {
        console.error('Failed to connect to MongoDB:', err.message);
        process.exit(1);
    }
};
connectToMongoDB();

// User Schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, // Added unique: true
    email: { type: String, required: true, unique: true },
    password: { type: String },
    socialId: { type: String },
    signupMethod: { type: String, required: true },
    profilePicture: { type: String }, // Base64 string for profile picture
    isAdmin: { type: Boolean, default: false }, // Field to indicate admin status
});
const User = mongoose.model('User', userSchema);

// Middleware to check if user is admin
const isAdmin = async (req, res, next) => {
    try {
        const userId = req.headers['user-id'];
        if (!userId) {
            console.log('No user-id header provided');
            return res.status(401).json({ message: 'User ID required.' });
        }

        const user = await User.findById(userId);
        if (!user) {
            console.log('User not found for ID:', userId);
            return res.status(404).json({ message: 'User not found.' });
        }

        if (!user.isAdmin) {
            console.log('Non-admin user attempted access:', userId);
            return res.status(403).json({ message: 'Access denied. Admin privileges required.' });
        }

        next();
    } catch (err) {
        console.error('Error in isAdmin middleware:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
};

// Get All Users (Admin Only)
app.get('/api/users', isAdmin, async (req, res) => {
    try {
        // Change to { isAdmin: true } to list only admin users
        const users = await User.find({}, 'username email isAdmin profilePicture signupMethod');
        console.log('Fetched all users:', users);
        res.status(200).json({
            message: 'Users retrieved successfully.',
            users,
        });
    } catch (err) {
        console.error('Error fetching users:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
});

// Register User
app.post('/api/users/register', async (req, res) => {
    console.log('Received register request:', req.body);
    try {
        const { username, email, password, socialId, signupMethod } = req.body;

        // Check for existing username
        const existingUsername = await User.findOne({ username });
        if (existingUsername) {
            console.log('Username already exists:', username);
            return res.status(400).json({ message: 'Username already exists.' });
        }

        // Check for existing email
        const existingEmail = await User.findOne({ email });
        if (existingEmail) {
            console.log('Email already exists:', email);
            return res.status(400).json({ message: 'Email already exists.' });
        }

        // Validate strong password for form signup
        if (signupMethod === 'form' && password) {
            const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
            if (!strongPasswordRegex.test(password)) {
                console.log('Weak password for:', email);
                return res.status(400).json({
                    message: 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character (!@#$%^&*).'
                });
            }
        }

        let hashedPassword = null;
        if (password) {
            hashedPassword = await bcrypt.hash(password, 10);
            console.log('Password hashed successfully');
        }

        const user = new User({
            username,
            email,
            password: hashedPassword,
            socialId,
            signupMethod,
            profilePicture: '',
            isAdmin: false, // Default to non-admin
        });

        await user.save();
        console.log('User saved successfully:', user);
        res.status(201).json({
            message: 'User registered successfully.',
            userId: user._id.toString(), // Include userId in response
        });
    } catch (err) {
        console.error('Error in register:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
});

// Login User (Form)
app.post('/api/users/login', async (req, res) => {
    console.log('Received login request:', req.body);
    try {
        const { usernameEmail, password } = req.body;
        const user = await User.findOne({
            $or: [{ username: usernameEmail }, { email: usernameEmail }],
            signupMethod: 'form',
        });

        if (!user || !user.password) {
            console.log('User not found or no password:', usernameEmail);
            return res.status(401).json({ message: 'Invalid credentials.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            console.log('Password mismatch for:', usernameEmail);
            return res.status(401).json({ message: 'Invalid credentials.' });
        }

        console.log('Login successful for:', usernameEmail);
        res.status(200).json({
            message: 'Login successful.',
            user: {
                id: user._id.toString(),
                username: user.username,
                email: user.email,
                profilePicture: user.profilePicture,
                isAdmin: user.isAdmin,
            },
        });
    } catch (err) {
        console.error('Error in login:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
});

// Social Login
app.post('/api/users/social-login', async (req, res) => {
    console.log('Received social-login request:', req.body);
    try {
        const { email, signupMethod } = req.body;
        const user = await User.findOne({ email, signupMethod });
        if (!user) {
            console.log('Social account not found for email:', email);
            return res.status(401).json({ message: 'Social account not found.' });
        }

        console.log('Social login successful for email:', email);
        res.status(200).json({
            message: 'Social login successful.',
            user: {
                id: user._id.toString(),
                username: user.username,
                email: user.email,
                profilePicture: user.profilePicture,
                isAdmin: user.isAdmin,
            },
        });
    } catch (err) {
        console.error('Error in social-login:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
});

// Get User Details
app.get('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }
        res.status(200).json({
            id: user._id.toString(),
            username: user.username,
            email: user.email,
            profilePicture: user.profilePicture,
            isAdmin: user.isAdmin,
        });
    } catch (err) {
        console.error('Error fetching user:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
});

// Update User Details
app.put('/api/users/:id', async (req, res) => {
    console.log('Received update request:', req.body);
    try {
        const { username, email, password, profilePicture } = req.body;
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        // Check if new username is unique (if provided and different)
        if (username && username !== user.username) {
            const existingUsername = await User.findOne({ username });
            if (existingUsername) {
                console.log('Username already exists:', username);
                return res.status(400).json({ message: 'Username already exists.' });
            }
        }

        // Check if new email is unique (if provided and different)
        if (email && email !== user.email) {
            const existingEmail = await User.findOne({ email });
            if (existingEmail) {
                console.log('Email already exists:', email);
                return res.status(400).json({ message: 'Email already exists.' });
            }
        }

        user.username = username || user.username;
        user.email = email || user.email;
        if (password) {
            // Validate strong password for updates
            const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
            if (!strongPasswordRegex.test(password)) {
                console.log('Weak password for:', user.email);
                return res.status(400).json({
                    message: 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character (!@#$%^&*).'
                });
            }
            user.password = await bcrypt.hash(password, 10);
        }
        user.profilePicture = profilePicture || user.profilePicture;

        await user.save();
        console.log('User updated successfully:', user);
        res.status(200).json({
            message: 'User updated successfully.',
            user: {
                id: user._id.toString(),
                username: user.username,
                email: user.email,
                profilePicture: user.profilePicture,
                isAdmin: user.isAdmin,
            },
        });
    } catch (err) {
        console.error('Error updating user:', err.message);
        res.status(500).json({ message: `Server error: ${err.message}` });
    }
});

// Error handling for payload too large
app.use((err, req, res, next) => {
    if (err.type === 'entity.too.large') {
        return res.status(413).json({ message: 'Uploaded file is too large. Please use an image smaller than 10MB.' });
    }
    next(err);
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});